/**
 */
package rilaiotmqtt;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>cloud</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link rilaiotmqtt.cloud#getCanal <em>Canal</em>}</li>
 *   <li>{@link rilaiotmqtt.cloud#getIp <em>Ip</em>}</li>
 *   <li>{@link rilaiotmqtt.cloud#isStatus <em>Status</em>}</li>
 *   <li>{@link rilaiotmqtt.cloud#getTemperatura <em>Temperatura</em>}</li>
 * </ul>
 *
 * @see rilaiotmqtt.RilaiotmqttPackage#getcloud()
 * @model
 * @generated
 */
public interface cloud extends EObject {
	/**
	 * Returns the value of the '<em><b>Canal</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Canal</em>' attribute.
	 * @see #setCanal(int)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getcloud_Canal()
	 * @model required="true"
	 * @generated
	 */
	int getCanal();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.cloud#getCanal <em>Canal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Canal</em>' attribute.
	 * @see #getCanal()
	 * @generated
	 */
	void setCanal(int value);

	/**
	 * Returns the value of the '<em><b>Ip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ip</em>' attribute.
	 * @see #setIp(String)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getcloud_Ip()
	 * @model required="true"
	 * @generated
	 */
	String getIp();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.cloud#getIp <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ip</em>' attribute.
	 * @see #getIp()
	 * @generated
	 */
	void setIp(String value);

	/**
	 * Returns the value of the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status</em>' attribute.
	 * @see #setStatus(boolean)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getcloud_Status()
	 * @model required="true"
	 * @generated
	 */
	boolean isStatus();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.cloud#isStatus <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status</em>' attribute.
	 * @see #isStatus()
	 * @generated
	 */
	void setStatus(boolean value);

	/**
	 * Returns the value of the '<em><b>Temperatura</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Temperatura</em>' attribute.
	 * @see #setTemperatura(float)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getcloud_Temperatura()
	 * @model required="true"
	 * @generated
	 */
	float getTemperatura();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.cloud#getTemperatura <em>Temperatura</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Temperatura</em>' attribute.
	 * @see #getTemperatura()
	 * @generated
	 */
	void setTemperatura(float value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void recupera_Canal(String ip, int canal);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void armazena_Temperatura(String ip, float temperatura);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void armazena_Status(String ip, boolean status);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void armazena_Canal(String ip, int canal);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void recupera_Status(String ip, boolean status);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void recupera_Temperatura(String ip, float temperatura);

} // cloud
