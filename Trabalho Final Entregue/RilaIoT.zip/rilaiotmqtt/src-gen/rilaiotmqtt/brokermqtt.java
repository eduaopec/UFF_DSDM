/**
 */
package rilaiotmqtt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>brokermqtt</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link rilaiotmqtt.brokermqtt#getIp <em>Ip</em>}</li>
 *   <li>{@link rilaiotmqtt.brokermqtt#getMensagem <em>Mensagem</em>}</li>
 *   <li>{@link rilaiotmqtt.brokermqtt#getAssinante <em>Assinante</em>}</li>
 * </ul>
 *
 * @see rilaiotmqtt.RilaiotmqttPackage#getbrokermqtt()
 * @model
 * @generated
 */
public interface brokermqtt extends EObject {
	/**
	 * Returns the value of the '<em><b>Ip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ip</em>' attribute.
	 * @see #setIp(String)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getbrokermqtt_Ip()
	 * @model required="true"
	 * @generated
	 */
	String getIp();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.brokermqtt#getIp <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ip</em>' attribute.
	 * @see #getIp()
	 * @generated
	 */
	void setIp(String value);

	/**
	 * Returns the value of the '<em><b>Mensagem</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiotmqtt.mensagem}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mensagem</em>' containment reference list.
	 * @see rilaiotmqtt.RilaiotmqttPackage#getbrokermqtt_Mensagem()
	 * @model containment="true"
	 * @generated
	 */
	EList<mensagem> getMensagem();

	/**
	 * Returns the value of the '<em><b>Assinante</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiotmqtt.assinante}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Assinante</em>' containment reference list.
	 * @see rilaiotmqtt.RilaiotmqttPackage#getbrokermqtt_Assinante()
	 * @model containment="true"
	 * @generated
	 */
	EList<assinante> getAssinante();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void subscribe(String ip_cliente, String topico);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void publish(String ipSubscribe, String mensagem);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void unsubscribe(String ip_cliente, String topico);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void armazena_Mensagem(String ip, String mensagem);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void recupera_Mensagem(String ip, String mensagem);

} // brokermqtt
