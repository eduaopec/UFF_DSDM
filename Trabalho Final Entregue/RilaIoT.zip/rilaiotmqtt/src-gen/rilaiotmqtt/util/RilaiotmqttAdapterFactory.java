/**
 */
package rilaiotmqtt.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

import rilaiotmqtt.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see rilaiotmqtt.RilaiotmqttPackage
 * @generated
 */
public class RilaiotmqttAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static RilaiotmqttPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RilaiotmqttAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = RilaiotmqttPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RilaiotmqttSwitch<Adapter> modelSwitch = new RilaiotmqttSwitch<Adapter>() {
		@Override
		public Adapter caseaplicacao(aplicacao object) {
			return createaplicacaoAdapter();
		}

		@Override
		public Adapter casegeladeira(geladeira object) {
			return creategeladeiraAdapter();
		}

		@Override
		public Adapter casetv(tv object) {
			return createtvAdapter();
		}

		@Override
		public Adapter casebrokermqtt(brokermqtt object) {
			return createbrokermqttAdapter();
		}

		@Override
		public Adapter casemensagem(mensagem object) {
			return createmensagemAdapter();
		}

		@Override
		public Adapter caseassinante(assinante object) {
			return createassinanteAdapter();
		}

		@Override
		public Adapter casecloud(cloud object) {
			return createcloudAdapter();
		}

		@Override
		public Adapter casesensor(sensor object) {
			return createsensorAdapter();
		}

		@Override
		public Adapter caseatuador(atuador object) {
			return createatuadorAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link rilaiotmqtt.aplicacao <em>aplicacao</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see rilaiotmqtt.aplicacao
	 * @generated
	 */
	public Adapter createaplicacaoAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link rilaiotmqtt.geladeira <em>geladeira</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see rilaiotmqtt.geladeira
	 * @generated
	 */
	public Adapter creategeladeiraAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link rilaiotmqtt.tv <em>tv</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see rilaiotmqtt.tv
	 * @generated
	 */
	public Adapter createtvAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link rilaiotmqtt.brokermqtt <em>brokermqtt</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see rilaiotmqtt.brokermqtt
	 * @generated
	 */
	public Adapter createbrokermqttAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link rilaiotmqtt.mensagem <em>mensagem</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see rilaiotmqtt.mensagem
	 * @generated
	 */
	public Adapter createmensagemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link rilaiotmqtt.assinante <em>assinante</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see rilaiotmqtt.assinante
	 * @generated
	 */
	public Adapter createassinanteAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link rilaiotmqtt.cloud <em>cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see rilaiotmqtt.cloud
	 * @generated
	 */
	public Adapter createcloudAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link rilaiotmqtt.sensor <em>sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see rilaiotmqtt.sensor
	 * @generated
	 */
	public Adapter createsensorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link rilaiotmqtt.atuador <em>atuador</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see rilaiotmqtt.atuador
	 * @generated
	 */
	public Adapter createatuadorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //RilaiotmqttAdapterFactory
