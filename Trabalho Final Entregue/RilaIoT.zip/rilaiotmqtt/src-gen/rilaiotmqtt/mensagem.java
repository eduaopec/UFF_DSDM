/**
 */
package rilaiotmqtt;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>mensagem</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link rilaiotmqtt.mensagem#getStatus <em>Status</em>}</li>
 *   <li>{@link rilaiotmqtt.mensagem#getMensagem <em>Mensagem</em>}</li>
 *   <li>{@link rilaiotmqtt.mensagem#getTopico <em>Topico</em>}</li>
 *   <li>{@link rilaiotmqtt.mensagem#getIp_origem <em>Ip origem</em>}</li>
 * </ul>
 *
 * @see rilaiotmqtt.RilaiotmqttPackage#getmensagem()
 * @model
 * @generated
 */
public interface mensagem extends EObject {
	/**
	 * Returns the value of the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status</em>' attribute.
	 * @see #setStatus(String)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getmensagem_Status()
	 * @model required="true"
	 * @generated
	 */
	String getStatus();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.mensagem#getStatus <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status</em>' attribute.
	 * @see #getStatus()
	 * @generated
	 */
	void setStatus(String value);

	/**
	 * Returns the value of the '<em><b>Mensagem</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mensagem</em>' attribute.
	 * @see #setMensagem(String)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getmensagem_Mensagem()
	 * @model required="true"
	 * @generated
	 */
	String getMensagem();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.mensagem#getMensagem <em>Mensagem</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Mensagem</em>' attribute.
	 * @see #getMensagem()
	 * @generated
	 */
	void setMensagem(String value);

	/**
	 * Returns the value of the '<em><b>Topico</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Topico</em>' attribute.
	 * @see #setTopico(String)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getmensagem_Topico()
	 * @model required="true"
	 * @generated
	 */
	String getTopico();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.mensagem#getTopico <em>Topico</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Topico</em>' attribute.
	 * @see #getTopico()
	 * @generated
	 */
	void setTopico(String value);

	/**
	 * Returns the value of the '<em><b>Ip origem</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ip origem</em>' attribute.
	 * @see #setIp_origem(String)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getmensagem_Ip_origem()
	 * @model required="true"
	 * @generated
	 */
	String getIp_origem();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.mensagem#getIp_origem <em>Ip origem</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ip origem</em>' attribute.
	 * @see #getIp_origem()
	 * @generated
	 */
	void setIp_origem(String value);

} // mensagem
