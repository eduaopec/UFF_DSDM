/**
 */
package rilaiotmqtt;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see rilaiotmqtt.RilaiotmqttPackage
 * @generated
 */
public interface RilaiotmqttFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	RilaiotmqttFactory eINSTANCE = rilaiotmqtt.impl.RilaiotmqttFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>aplicacao</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>aplicacao</em>'.
	 * @generated
	 */
	aplicacao createaplicacao();

	/**
	 * Returns a new object of class '<em>geladeira</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>geladeira</em>'.
	 * @generated
	 */
	geladeira creategeladeira();

	/**
	 * Returns a new object of class '<em>tv</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>tv</em>'.
	 * @generated
	 */
	tv createtv();

	/**
	 * Returns a new object of class '<em>brokermqtt</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>brokermqtt</em>'.
	 * @generated
	 */
	brokermqtt createbrokermqtt();

	/**
	 * Returns a new object of class '<em>mensagem</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>mensagem</em>'.
	 * @generated
	 */
	mensagem createmensagem();

	/**
	 * Returns a new object of class '<em>assinante</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>assinante</em>'.
	 * @generated
	 */
	assinante createassinante();

	/**
	 * Returns a new object of class '<em>cloud</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>cloud</em>'.
	 * @generated
	 */
	cloud createcloud();

	/**
	 * Returns a new object of class '<em>sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>sensor</em>'.
	 * @generated
	 */
	sensor createsensor();

	/**
	 * Returns a new object of class '<em>atuador</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>atuador</em>'.
	 * @generated
	 */
	atuador createatuador();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	RilaiotmqttPackage getRilaiotmqttPackage();

} //RilaiotmqttFactory
