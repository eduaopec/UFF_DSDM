/**
 */
package rilaiotmqtt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>tv</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link rilaiotmqtt.tv#getIp <em>Ip</em>}</li>
 *   <li>{@link rilaiotmqtt.tv#getCanal <em>Canal</em>}</li>
 *   <li>{@link rilaiotmqtt.tv#isStatus <em>Status</em>}</li>
 *   <li>{@link rilaiotmqtt.tv#getCloud_tv <em>Cloud tv</em>}</li>
 *   <li>{@link rilaiotmqtt.tv#getSensor_tv <em>Sensor tv</em>}</li>
 *   <li>{@link rilaiotmqtt.tv#getAtuador_tv <em>Atuador tv</em>}</li>
 * </ul>
 *
 * @see rilaiotmqtt.RilaiotmqttPackage#gettv()
 * @model
 * @generated
 */
public interface tv extends EObject {
	/**
	 * Returns the value of the '<em><b>Ip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ip</em>' attribute.
	 * @see #setIp(String)
	 * @see rilaiotmqtt.RilaiotmqttPackage#gettv_Ip()
	 * @model required="true"
	 * @generated
	 */
	String getIp();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.tv#getIp <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ip</em>' attribute.
	 * @see #getIp()
	 * @generated
	 */
	void setIp(String value);

	/**
	 * Returns the value of the '<em><b>Canal</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Canal</em>' attribute.
	 * @see #setCanal(int)
	 * @see rilaiotmqtt.RilaiotmqttPackage#gettv_Canal()
	 * @model required="true"
	 * @generated
	 */
	int getCanal();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.tv#getCanal <em>Canal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Canal</em>' attribute.
	 * @see #getCanal()
	 * @generated
	 */
	void setCanal(int value);

	/**
	 * Returns the value of the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status</em>' attribute.
	 * @see #setStatus(boolean)
	 * @see rilaiotmqtt.RilaiotmqttPackage#gettv_Status()
	 * @model required="true"
	 * @generated
	 */
	boolean isStatus();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.tv#isStatus <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status</em>' attribute.
	 * @see #isStatus()
	 * @generated
	 */
	void setStatus(boolean value);

	/**
	 * Returns the value of the '<em><b>Cloud tv</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiotmqtt.cloud}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cloud tv</em>' containment reference list.
	 * @see rilaiotmqtt.RilaiotmqttPackage#gettv_Cloud_tv()
	 * @model containment="true"
	 * @generated
	 */
	EList<cloud> getCloud_tv();

	/**
	 * Returns the value of the '<em><b>Sensor tv</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiotmqtt.sensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sensor tv</em>' containment reference list.
	 * @see rilaiotmqtt.RilaiotmqttPackage#gettv_Sensor_tv()
	 * @model containment="true"
	 * @generated
	 */
	EList<sensor> getSensor_tv();

	/**
	 * Returns the value of the '<em><b>Atuador tv</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiotmqtt.atuador}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Atuador tv</em>' containment reference list.
	 * @see rilaiotmqtt.RilaiotmqttPackage#gettv_Atuador_tv()
	 * @model containment="true"
	 * @generated
	 */
	EList<atuador> getAtuador_tv();

} // tv
