/**
 */
package rilaiotmqtt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>aplicacao</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link rilaiotmqtt.aplicacao#getNome <em>Nome</em>}</li>
 *   <li>{@link rilaiotmqtt.aplicacao#getBrokermqtt <em>Brokermqtt</em>}</li>
 *   <li>{@link rilaiotmqtt.aplicacao#getTv <em>Tv</em>}</li>
 *   <li>{@link rilaiotmqtt.aplicacao#getGeladeira <em>Geladeira</em>}</li>
 * </ul>
 *
 * @see rilaiotmqtt.RilaiotmqttPackage#getaplicacao()
 * @model
 * @generated
 */
public interface aplicacao extends EObject {
	/**
	 * Returns the value of the '<em><b>Nome</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nome</em>' attribute.
	 * @see #setNome(String)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getaplicacao_Nome()
	 * @model required="true"
	 * @generated
	 */
	String getNome();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.aplicacao#getNome <em>Nome</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nome</em>' attribute.
	 * @see #getNome()
	 * @generated
	 */
	void setNome(String value);

	/**
	 * Returns the value of the '<em><b>Brokermqtt</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Brokermqtt</em>' containment reference.
	 * @see #setBrokermqtt(brokermqtt)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getaplicacao_Brokermqtt()
	 * @model containment="true" required="true"
	 * @generated
	 */
	brokermqtt getBrokermqtt();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.aplicacao#getBrokermqtt <em>Brokermqtt</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Brokermqtt</em>' containment reference.
	 * @see #getBrokermqtt()
	 * @generated
	 */
	void setBrokermqtt(brokermqtt value);

	/**
	 * Returns the value of the '<em><b>Tv</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiotmqtt.tv}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tv</em>' containment reference list.
	 * @see rilaiotmqtt.RilaiotmqttPackage#getaplicacao_Tv()
	 * @model containment="true"
	 * @generated
	 */
	EList<tv> getTv();

	/**
	 * Returns the value of the '<em><b>Geladeira</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiotmqtt.geladeira}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Geladeira</em>' containment reference list.
	 * @see rilaiotmqtt.RilaiotmqttPackage#getaplicacao_Geladeira()
	 * @model containment="true"
	 * @generated
	 */
	EList<geladeira> getGeladeira();

} // aplicacao
