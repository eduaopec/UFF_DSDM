/**
 */
package rilaiotmqtt.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import rilaiotmqtt.RilaiotmqttPackage;
import rilaiotmqtt.atuador;
import rilaiotmqtt.cloud;
import rilaiotmqtt.sensor;
import rilaiotmqtt.tv;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>tv</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link rilaiotmqtt.impl.tvImpl#getIp <em>Ip</em>}</li>
 *   <li>{@link rilaiotmqtt.impl.tvImpl#getCanal <em>Canal</em>}</li>
 *   <li>{@link rilaiotmqtt.impl.tvImpl#isStatus <em>Status</em>}</li>
 *   <li>{@link rilaiotmqtt.impl.tvImpl#getCloud_tv <em>Cloud tv</em>}</li>
 *   <li>{@link rilaiotmqtt.impl.tvImpl#getSensor_tv <em>Sensor tv</em>}</li>
 *   <li>{@link rilaiotmqtt.impl.tvImpl#getAtuador_tv <em>Atuador tv</em>}</li>
 * </ul>
 *
 * @generated
 */
public class tvImpl extends MinimalEObjectImpl.Container implements tv {
	/**
	 * The default value of the '{@link #getIp() <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIp()
	 * @generated
	 * @ordered
	 */
	protected static final String IP_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIp() <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIp()
	 * @generated
	 * @ordered
	 */
	protected String ip = IP_EDEFAULT;

	/**
	 * The default value of the '{@link #getCanal() <em>Canal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCanal()
	 * @generated
	 * @ordered
	 */
	protected static final int CANAL_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCanal() <em>Canal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCanal()
	 * @generated
	 * @ordered
	 */
	protected int canal = CANAL_EDEFAULT;

	/**
	 * The default value of the '{@link #isStatus() <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isStatus()
	 * @generated
	 * @ordered
	 */
	protected static final boolean STATUS_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isStatus() <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isStatus()
	 * @generated
	 * @ordered
	 */
	protected boolean status = STATUS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCloud_tv() <em>Cloud tv</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCloud_tv()
	 * @generated
	 * @ordered
	 */
	protected EList<cloud> cloud_tv;

	/**
	 * The cached value of the '{@link #getSensor_tv() <em>Sensor tv</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSensor_tv()
	 * @generated
	 * @ordered
	 */
	protected EList<sensor> sensor_tv;

	/**
	 * The cached value of the '{@link #getAtuador_tv() <em>Atuador tv</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAtuador_tv()
	 * @generated
	 * @ordered
	 */
	protected EList<atuador> atuador_tv;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected tvImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RilaiotmqttPackage.Literals.TV;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIp() {
		return ip;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIp(String newIp) {
		String oldIp = ip;
		ip = newIp;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotmqttPackage.TV__IP, oldIp, ip));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getCanal() {
		return canal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCanal(int newCanal) {
		int oldCanal = canal;
		canal = newCanal;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotmqttPackage.TV__CANAL, oldCanal, canal));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isStatus() {
		return status;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStatus(boolean newStatus) {
		boolean oldStatus = status;
		status = newStatus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotmqttPackage.TV__STATUS, oldStatus, status));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<cloud> getCloud_tv() {
		if (cloud_tv == null) {
			cloud_tv = new EObjectContainmentEList<cloud>(cloud.class, this, RilaiotmqttPackage.TV__CLOUD_TV);
		}
		return cloud_tv;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<sensor> getSensor_tv() {
		if (sensor_tv == null) {
			sensor_tv = new EObjectContainmentEList<sensor>(sensor.class, this, RilaiotmqttPackage.TV__SENSOR_TV);
		}
		return sensor_tv;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<atuador> getAtuador_tv() {
		if (atuador_tv == null) {
			atuador_tv = new EObjectContainmentEList<atuador>(atuador.class, this, RilaiotmqttPackage.TV__ATUADOR_TV);
		}
		return atuador_tv;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case RilaiotmqttPackage.TV__CLOUD_TV:
			return ((InternalEList<?>) getCloud_tv()).basicRemove(otherEnd, msgs);
		case RilaiotmqttPackage.TV__SENSOR_TV:
			return ((InternalEList<?>) getSensor_tv()).basicRemove(otherEnd, msgs);
		case RilaiotmqttPackage.TV__ATUADOR_TV:
			return ((InternalEList<?>) getAtuador_tv()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case RilaiotmqttPackage.TV__IP:
			return getIp();
		case RilaiotmqttPackage.TV__CANAL:
			return getCanal();
		case RilaiotmqttPackage.TV__STATUS:
			return isStatus();
		case RilaiotmqttPackage.TV__CLOUD_TV:
			return getCloud_tv();
		case RilaiotmqttPackage.TV__SENSOR_TV:
			return getSensor_tv();
		case RilaiotmqttPackage.TV__ATUADOR_TV:
			return getAtuador_tv();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case RilaiotmqttPackage.TV__IP:
			setIp((String) newValue);
			return;
		case RilaiotmqttPackage.TV__CANAL:
			setCanal((Integer) newValue);
			return;
		case RilaiotmqttPackage.TV__STATUS:
			setStatus((Boolean) newValue);
			return;
		case RilaiotmqttPackage.TV__CLOUD_TV:
			getCloud_tv().clear();
			getCloud_tv().addAll((Collection<? extends cloud>) newValue);
			return;
		case RilaiotmqttPackage.TV__SENSOR_TV:
			getSensor_tv().clear();
			getSensor_tv().addAll((Collection<? extends sensor>) newValue);
			return;
		case RilaiotmqttPackage.TV__ATUADOR_TV:
			getAtuador_tv().clear();
			getAtuador_tv().addAll((Collection<? extends atuador>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case RilaiotmqttPackage.TV__IP:
			setIp(IP_EDEFAULT);
			return;
		case RilaiotmqttPackage.TV__CANAL:
			setCanal(CANAL_EDEFAULT);
			return;
		case RilaiotmqttPackage.TV__STATUS:
			setStatus(STATUS_EDEFAULT);
			return;
		case RilaiotmqttPackage.TV__CLOUD_TV:
			getCloud_tv().clear();
			return;
		case RilaiotmqttPackage.TV__SENSOR_TV:
			getSensor_tv().clear();
			return;
		case RilaiotmqttPackage.TV__ATUADOR_TV:
			getAtuador_tv().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case RilaiotmqttPackage.TV__IP:
			return IP_EDEFAULT == null ? ip != null : !IP_EDEFAULT.equals(ip);
		case RilaiotmqttPackage.TV__CANAL:
			return canal != CANAL_EDEFAULT;
		case RilaiotmqttPackage.TV__STATUS:
			return status != STATUS_EDEFAULT;
		case RilaiotmqttPackage.TV__CLOUD_TV:
			return cloud_tv != null && !cloud_tv.isEmpty();
		case RilaiotmqttPackage.TV__SENSOR_TV:
			return sensor_tv != null && !sensor_tv.isEmpty();
		case RilaiotmqttPackage.TV__ATUADOR_TV:
			return atuador_tv != null && !atuador_tv.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (ip: ");
		result.append(ip);
		result.append(", canal: ");
		result.append(canal);
		result.append(", status: ");
		result.append(status);
		result.append(')');
		return result.toString();
	}

} //tvImpl
