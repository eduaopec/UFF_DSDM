/**
 */
package rilaiotmqtt.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import rilaiotmqtt.RilaiotmqttPackage;
import rilaiotmqtt.aplicacao;
import rilaiotmqtt.brokermqtt;
import rilaiotmqtt.geladeira;
import rilaiotmqtt.tv;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>aplicacao</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link rilaiotmqtt.impl.aplicacaoImpl#getNome <em>Nome</em>}</li>
 *   <li>{@link rilaiotmqtt.impl.aplicacaoImpl#getBrokermqtt <em>Brokermqtt</em>}</li>
 *   <li>{@link rilaiotmqtt.impl.aplicacaoImpl#getTv <em>Tv</em>}</li>
 *   <li>{@link rilaiotmqtt.impl.aplicacaoImpl#getGeladeira <em>Geladeira</em>}</li>
 * </ul>
 *
 * @generated
 */
public class aplicacaoImpl extends MinimalEObjectImpl.Container implements aplicacao {
	/**
	 * The default value of the '{@link #getNome() <em>Nome</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNome()
	 * @generated
	 * @ordered
	 */
	protected static final String NOME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNome() <em>Nome</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNome()
	 * @generated
	 * @ordered
	 */
	protected String nome = NOME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getBrokermqtt() <em>Brokermqtt</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBrokermqtt()
	 * @generated
	 * @ordered
	 */
	protected brokermqtt brokermqtt;

	/**
	 * The cached value of the '{@link #getTv() <em>Tv</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTv()
	 * @generated
	 * @ordered
	 */
	protected EList<tv> tv;

	/**
	 * The cached value of the '{@link #getGeladeira() <em>Geladeira</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGeladeira()
	 * @generated
	 * @ordered
	 */
	protected EList<geladeira> geladeira;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected aplicacaoImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RilaiotmqttPackage.Literals.APLICACAO;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getNome() {
		return nome;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setNome(String newNome) {
		String oldNome = nome;
		nome = newNome;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotmqttPackage.APLICACAO__NOME, oldNome, nome));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public brokermqtt getBrokermqtt() {
		return brokermqtt;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetBrokermqtt(brokermqtt newBrokermqtt, NotificationChain msgs) {
		brokermqtt oldBrokermqtt = brokermqtt;
		brokermqtt = newBrokermqtt;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					RilaiotmqttPackage.APLICACAO__BROKERMQTT, oldBrokermqtt, newBrokermqtt);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setBrokermqtt(brokermqtt newBrokermqtt) {
		if (newBrokermqtt != brokermqtt) {
			NotificationChain msgs = null;
			if (brokermqtt != null)
				msgs = ((InternalEObject) brokermqtt).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - RilaiotmqttPackage.APLICACAO__BROKERMQTT, null, msgs);
			if (newBrokermqtt != null)
				msgs = ((InternalEObject) newBrokermqtt).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - RilaiotmqttPackage.APLICACAO__BROKERMQTT, null, msgs);
			msgs = basicSetBrokermqtt(newBrokermqtt, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotmqttPackage.APLICACAO__BROKERMQTT,
					newBrokermqtt, newBrokermqtt));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<tv> getTv() {
		if (tv == null) {
			tv = new EObjectContainmentEList<tv>(tv.class, this, RilaiotmqttPackage.APLICACAO__TV);
		}
		return tv;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<geladeira> getGeladeira() {
		if (geladeira == null) {
			geladeira = new EObjectContainmentEList<geladeira>(geladeira.class, this,
					RilaiotmqttPackage.APLICACAO__GELADEIRA);
		}
		return geladeira;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case RilaiotmqttPackage.APLICACAO__BROKERMQTT:
			return basicSetBrokermqtt(null, msgs);
		case RilaiotmqttPackage.APLICACAO__TV:
			return ((InternalEList<?>) getTv()).basicRemove(otherEnd, msgs);
		case RilaiotmqttPackage.APLICACAO__GELADEIRA:
			return ((InternalEList<?>) getGeladeira()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case RilaiotmqttPackage.APLICACAO__NOME:
			return getNome();
		case RilaiotmqttPackage.APLICACAO__BROKERMQTT:
			return getBrokermqtt();
		case RilaiotmqttPackage.APLICACAO__TV:
			return getTv();
		case RilaiotmqttPackage.APLICACAO__GELADEIRA:
			return getGeladeira();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case RilaiotmqttPackage.APLICACAO__NOME:
			setNome((String) newValue);
			return;
		case RilaiotmqttPackage.APLICACAO__BROKERMQTT:
			setBrokermqtt((brokermqtt) newValue);
			return;
		case RilaiotmqttPackage.APLICACAO__TV:
			getTv().clear();
			getTv().addAll((Collection<? extends tv>) newValue);
			return;
		case RilaiotmqttPackage.APLICACAO__GELADEIRA:
			getGeladeira().clear();
			getGeladeira().addAll((Collection<? extends geladeira>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case RilaiotmqttPackage.APLICACAO__NOME:
			setNome(NOME_EDEFAULT);
			return;
		case RilaiotmqttPackage.APLICACAO__BROKERMQTT:
			setBrokermqtt((brokermqtt) null);
			return;
		case RilaiotmqttPackage.APLICACAO__TV:
			getTv().clear();
			return;
		case RilaiotmqttPackage.APLICACAO__GELADEIRA:
			getGeladeira().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case RilaiotmqttPackage.APLICACAO__NOME:
			return NOME_EDEFAULT == null ? nome != null : !NOME_EDEFAULT.equals(nome);
		case RilaiotmqttPackage.APLICACAO__BROKERMQTT:
			return brokermqtt != null;
		case RilaiotmqttPackage.APLICACAO__TV:
			return tv != null && !tv.isEmpty();
		case RilaiotmqttPackage.APLICACAO__GELADEIRA:
			return geladeira != null && !geladeira.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (nome: ");
		result.append(nome);
		result.append(')');
		return result.toString();
	}

} //aplicacaoImpl
