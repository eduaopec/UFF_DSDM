/**
 */
package rilaiotmqtt.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import rilaiotmqtt.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class RilaiotmqttFactoryImpl extends EFactoryImpl implements RilaiotmqttFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static RilaiotmqttFactory init() {
		try {
			RilaiotmqttFactory theRilaiotmqttFactory = (RilaiotmqttFactory) EPackage.Registry.INSTANCE
					.getEFactory(RilaiotmqttPackage.eNS_URI);
			if (theRilaiotmqttFactory != null) {
				return theRilaiotmqttFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new RilaiotmqttFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RilaiotmqttFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case RilaiotmqttPackage.APLICACAO:
			return createaplicacao();
		case RilaiotmqttPackage.GELADEIRA:
			return creategeladeira();
		case RilaiotmqttPackage.TV:
			return createtv();
		case RilaiotmqttPackage.BROKERMQTT:
			return createbrokermqtt();
		case RilaiotmqttPackage.MENSAGEM:
			return createmensagem();
		case RilaiotmqttPackage.ASSINANTE:
			return createassinante();
		case RilaiotmqttPackage.CLOUD:
			return createcloud();
		case RilaiotmqttPackage.SENSOR:
			return createsensor();
		case RilaiotmqttPackage.ATUADOR:
			return createatuador();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public aplicacao createaplicacao() {
		aplicacaoImpl aplicacao = new aplicacaoImpl();
		return aplicacao;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public geladeira creategeladeira() {
		geladeiraImpl geladeira = new geladeiraImpl();
		return geladeira;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public tv createtv() {
		tvImpl tv = new tvImpl();
		return tv;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public brokermqtt createbrokermqtt() {
		brokermqttImpl brokermqtt = new brokermqttImpl();
		return brokermqtt;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public mensagem createmensagem() {
		mensagemImpl mensagem = new mensagemImpl();
		return mensagem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public assinante createassinante() {
		assinanteImpl assinante = new assinanteImpl();
		return assinante;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public cloud createcloud() {
		cloudImpl cloud = new cloudImpl();
		return cloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public sensor createsensor() {
		sensorImpl sensor = new sensorImpl();
		return sensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public atuador createatuador() {
		atuadorImpl atuador = new atuadorImpl();
		return atuador;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RilaiotmqttPackage getRilaiotmqttPackage() {
		return (RilaiotmqttPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static RilaiotmqttPackage getPackage() {
		return RilaiotmqttPackage.eINSTANCE;
	}

} //RilaiotmqttFactoryImpl
