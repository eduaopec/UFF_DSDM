/**
 */
package rilaiotmqtt.impl;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import rilaiotmqtt.RilaiotmqttPackage;
import rilaiotmqtt.cloud;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>cloud</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link rilaiotmqtt.impl.cloudImpl#getCanal <em>Canal</em>}</li>
 *   <li>{@link rilaiotmqtt.impl.cloudImpl#getIp <em>Ip</em>}</li>
 *   <li>{@link rilaiotmqtt.impl.cloudImpl#isStatus <em>Status</em>}</li>
 *   <li>{@link rilaiotmqtt.impl.cloudImpl#getTemperatura <em>Temperatura</em>}</li>
 * </ul>
 *
 * @generated
 */
public class cloudImpl extends MinimalEObjectImpl.Container implements cloud {
	/**
	 * The default value of the '{@link #getCanal() <em>Canal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCanal()
	 * @generated
	 * @ordered
	 */
	protected static final int CANAL_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCanal() <em>Canal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCanal()
	 * @generated
	 * @ordered
	 */
	protected int canal = CANAL_EDEFAULT;

	/**
	 * The default value of the '{@link #getIp() <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIp()
	 * @generated
	 * @ordered
	 */
	protected static final String IP_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIp() <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIp()
	 * @generated
	 * @ordered
	 */
	protected String ip = IP_EDEFAULT;

	/**
	 * The default value of the '{@link #isStatus() <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isStatus()
	 * @generated
	 * @ordered
	 */
	protected static final boolean STATUS_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isStatus() <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isStatus()
	 * @generated
	 * @ordered
	 */
	protected boolean status = STATUS_EDEFAULT;

	/**
	 * The default value of the '{@link #getTemperatura() <em>Temperatura</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTemperatura()
	 * @generated
	 * @ordered
	 */
	protected static final float TEMPERATURA_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getTemperatura() <em>Temperatura</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTemperatura()
	 * @generated
	 * @ordered
	 */
	protected float temperatura = TEMPERATURA_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected cloudImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RilaiotmqttPackage.Literals.CLOUD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getCanal() {
		return canal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCanal(int newCanal) {
		int oldCanal = canal;
		canal = newCanal;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotmqttPackage.CLOUD__CANAL, oldCanal, canal));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIp() {
		return ip;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIp(String newIp) {
		String oldIp = ip;
		ip = newIp;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotmqttPackage.CLOUD__IP, oldIp, ip));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isStatus() {
		return status;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStatus(boolean newStatus) {
		boolean oldStatus = status;
		status = newStatus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotmqttPackage.CLOUD__STATUS, oldStatus, status));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getTemperatura() {
		return temperatura;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTemperatura(float newTemperatura) {
		float oldTemperatura = temperatura;
		temperatura = newTemperatura;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotmqttPackage.CLOUD__TEMPERATURA, oldTemperatura,
					temperatura));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void recupera_Canal(String ip, int canal) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void armazena_Temperatura(String ip, float temperatura) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void armazena_Status(String ip, boolean status) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void armazena_Canal(String ip, int canal) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void recupera_Status(String ip, boolean status) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void recupera_Temperatura(String ip, float temperatura) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case RilaiotmqttPackage.CLOUD__CANAL:
			return getCanal();
		case RilaiotmqttPackage.CLOUD__IP:
			return getIp();
		case RilaiotmqttPackage.CLOUD__STATUS:
			return isStatus();
		case RilaiotmqttPackage.CLOUD__TEMPERATURA:
			return getTemperatura();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case RilaiotmqttPackage.CLOUD__CANAL:
			setCanal((Integer) newValue);
			return;
		case RilaiotmqttPackage.CLOUD__IP:
			setIp((String) newValue);
			return;
		case RilaiotmqttPackage.CLOUD__STATUS:
			setStatus((Boolean) newValue);
			return;
		case RilaiotmqttPackage.CLOUD__TEMPERATURA:
			setTemperatura((Float) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case RilaiotmqttPackage.CLOUD__CANAL:
			setCanal(CANAL_EDEFAULT);
			return;
		case RilaiotmqttPackage.CLOUD__IP:
			setIp(IP_EDEFAULT);
			return;
		case RilaiotmqttPackage.CLOUD__STATUS:
			setStatus(STATUS_EDEFAULT);
			return;
		case RilaiotmqttPackage.CLOUD__TEMPERATURA:
			setTemperatura(TEMPERATURA_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case RilaiotmqttPackage.CLOUD__CANAL:
			return canal != CANAL_EDEFAULT;
		case RilaiotmqttPackage.CLOUD__IP:
			return IP_EDEFAULT == null ? ip != null : !IP_EDEFAULT.equals(ip);
		case RilaiotmqttPackage.CLOUD__STATUS:
			return status != STATUS_EDEFAULT;
		case RilaiotmqttPackage.CLOUD__TEMPERATURA:
			return temperatura != TEMPERATURA_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RilaiotmqttPackage.CLOUD___RECUPERA_CANAL__STRING_INT:
			recupera_Canal((String) arguments.get(0), (Integer) arguments.get(1));
			return null;
		case RilaiotmqttPackage.CLOUD___ARMAZENA_TEMPERATURA__STRING_FLOAT:
			armazena_Temperatura((String) arguments.get(0), (Float) arguments.get(1));
			return null;
		case RilaiotmqttPackage.CLOUD___ARMAZENA_STATUS__STRING_BOOLEAN:
			armazena_Status((String) arguments.get(0), (Boolean) arguments.get(1));
			return null;
		case RilaiotmqttPackage.CLOUD___ARMAZENA_CANAL__STRING_INT:
			armazena_Canal((String) arguments.get(0), (Integer) arguments.get(1));
			return null;
		case RilaiotmqttPackage.CLOUD___RECUPERA_STATUS__STRING_BOOLEAN:
			recupera_Status((String) arguments.get(0), (Boolean) arguments.get(1));
			return null;
		case RilaiotmqttPackage.CLOUD___RECUPERA_TEMPERATURA__STRING_FLOAT:
			recupera_Temperatura((String) arguments.get(0), (Float) arguments.get(1));
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (canal: ");
		result.append(canal);
		result.append(", ip: ");
		result.append(ip);
		result.append(", status: ");
		result.append(status);
		result.append(", temperatura: ");
		result.append(temperatura);
		result.append(')');
		return result.toString();
	}

} //cloudImpl
