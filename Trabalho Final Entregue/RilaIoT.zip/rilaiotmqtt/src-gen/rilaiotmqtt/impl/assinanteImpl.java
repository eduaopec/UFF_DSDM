/**
 */
package rilaiotmqtt.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import rilaiotmqtt.RilaiotmqttPackage;
import rilaiotmqtt.assinante;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>assinante</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link rilaiotmqtt.impl.assinanteImpl#getIp_origem <em>Ip origem</em>}</li>
 *   <li>{@link rilaiotmqtt.impl.assinanteImpl#getTopico <em>Topico</em>}</li>
 * </ul>
 *
 * @generated
 */
public class assinanteImpl extends MinimalEObjectImpl.Container implements assinante {
	/**
	 * The default value of the '{@link #getIp_origem() <em>Ip origem</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIp_origem()
	 * @generated
	 * @ordered
	 */
	protected static final String IP_ORIGEM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIp_origem() <em>Ip origem</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIp_origem()
	 * @generated
	 * @ordered
	 */
	protected String ip_origem = IP_ORIGEM_EDEFAULT;

	/**
	 * The default value of the '{@link #getTopico() <em>Topico</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTopico()
	 * @generated
	 * @ordered
	 */
	protected static final String TOPICO_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTopico() <em>Topico</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTopico()
	 * @generated
	 * @ordered
	 */
	protected String topico = TOPICO_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected assinanteImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RilaiotmqttPackage.Literals.ASSINANTE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIp_origem() {
		return ip_origem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIp_origem(String newIp_origem) {
		String oldIp_origem = ip_origem;
		ip_origem = newIp_origem;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotmqttPackage.ASSINANTE__IP_ORIGEM, oldIp_origem,
					ip_origem));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getTopico() {
		return topico;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTopico(String newTopico) {
		String oldTopico = topico;
		topico = newTopico;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotmqttPackage.ASSINANTE__TOPICO, oldTopico,
					topico));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case RilaiotmqttPackage.ASSINANTE__IP_ORIGEM:
			return getIp_origem();
		case RilaiotmqttPackage.ASSINANTE__TOPICO:
			return getTopico();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case RilaiotmqttPackage.ASSINANTE__IP_ORIGEM:
			setIp_origem((String) newValue);
			return;
		case RilaiotmqttPackage.ASSINANTE__TOPICO:
			setTopico((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case RilaiotmqttPackage.ASSINANTE__IP_ORIGEM:
			setIp_origem(IP_ORIGEM_EDEFAULT);
			return;
		case RilaiotmqttPackage.ASSINANTE__TOPICO:
			setTopico(TOPICO_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case RilaiotmqttPackage.ASSINANTE__IP_ORIGEM:
			return IP_ORIGEM_EDEFAULT == null ? ip_origem != null : !IP_ORIGEM_EDEFAULT.equals(ip_origem);
		case RilaiotmqttPackage.ASSINANTE__TOPICO:
			return TOPICO_EDEFAULT == null ? topico != null : !TOPICO_EDEFAULT.equals(topico);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (ip_origem: ");
		result.append(ip_origem);
		result.append(", topico: ");
		result.append(topico);
		result.append(')');
		return result.toString();
	}

} //assinanteImpl
