/**
 */
package rilaiotmqtt.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import rilaiotmqtt.RilaiotmqttPackage;
import rilaiotmqtt.assinante;
import rilaiotmqtt.brokermqtt;
import rilaiotmqtt.mensagem;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>brokermqtt</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link rilaiotmqtt.impl.brokermqttImpl#getIp <em>Ip</em>}</li>
 *   <li>{@link rilaiotmqtt.impl.brokermqttImpl#getMensagem <em>Mensagem</em>}</li>
 *   <li>{@link rilaiotmqtt.impl.brokermqttImpl#getAssinante <em>Assinante</em>}</li>
 * </ul>
 *
 * @generated
 */
public class brokermqttImpl extends MinimalEObjectImpl.Container implements brokermqtt {
	/**
	 * The default value of the '{@link #getIp() <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIp()
	 * @generated
	 * @ordered
	 */
	protected static final String IP_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIp() <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIp()
	 * @generated
	 * @ordered
	 */
	protected String ip = IP_EDEFAULT;

	/**
	 * The cached value of the '{@link #getMensagem() <em>Mensagem</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMensagem()
	 * @generated
	 * @ordered
	 */
	protected EList<mensagem> mensagem;

	/**
	 * The cached value of the '{@link #getAssinante() <em>Assinante</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAssinante()
	 * @generated
	 * @ordered
	 */
	protected EList<assinante> assinante;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected brokermqttImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RilaiotmqttPackage.Literals.BROKERMQTT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIp() {
		return ip;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIp(String newIp) {
		String oldIp = ip;
		ip = newIp;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotmqttPackage.BROKERMQTT__IP, oldIp, ip));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<mensagem> getMensagem() {
		if (mensagem == null) {
			mensagem = new EObjectContainmentEList<mensagem>(mensagem.class, this,
					RilaiotmqttPackage.BROKERMQTT__MENSAGEM);
		}
		return mensagem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<assinante> getAssinante() {
		if (assinante == null) {
			assinante = new EObjectContainmentEList<assinante>(assinante.class, this,
					RilaiotmqttPackage.BROKERMQTT__ASSINANTE);
		}
		return assinante;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void subscribe(String ip_cliente, String topico) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void publish(String ipSubscribe, String mensagem) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void unsubscribe(String ip_cliente, String topico) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void armazena_Mensagem(String ip, String mensagem) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void recupera_Mensagem(String ip, String mensagem) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case RilaiotmqttPackage.BROKERMQTT__MENSAGEM:
			return ((InternalEList<?>) getMensagem()).basicRemove(otherEnd, msgs);
		case RilaiotmqttPackage.BROKERMQTT__ASSINANTE:
			return ((InternalEList<?>) getAssinante()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case RilaiotmqttPackage.BROKERMQTT__IP:
			return getIp();
		case RilaiotmqttPackage.BROKERMQTT__MENSAGEM:
			return getMensagem();
		case RilaiotmqttPackage.BROKERMQTT__ASSINANTE:
			return getAssinante();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case RilaiotmqttPackage.BROKERMQTT__IP:
			setIp((String) newValue);
			return;
		case RilaiotmqttPackage.BROKERMQTT__MENSAGEM:
			getMensagem().clear();
			getMensagem().addAll((Collection<? extends mensagem>) newValue);
			return;
		case RilaiotmqttPackage.BROKERMQTT__ASSINANTE:
			getAssinante().clear();
			getAssinante().addAll((Collection<? extends assinante>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case RilaiotmqttPackage.BROKERMQTT__IP:
			setIp(IP_EDEFAULT);
			return;
		case RilaiotmqttPackage.BROKERMQTT__MENSAGEM:
			getMensagem().clear();
			return;
		case RilaiotmqttPackage.BROKERMQTT__ASSINANTE:
			getAssinante().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case RilaiotmqttPackage.BROKERMQTT__IP:
			return IP_EDEFAULT == null ? ip != null : !IP_EDEFAULT.equals(ip);
		case RilaiotmqttPackage.BROKERMQTT__MENSAGEM:
			return mensagem != null && !mensagem.isEmpty();
		case RilaiotmqttPackage.BROKERMQTT__ASSINANTE:
			return assinante != null && !assinante.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RilaiotmqttPackage.BROKERMQTT___SUBSCRIBE__STRING_STRING:
			subscribe((String) arguments.get(0), (String) arguments.get(1));
			return null;
		case RilaiotmqttPackage.BROKERMQTT___PUBLISH__STRING_STRING:
			publish((String) arguments.get(0), (String) arguments.get(1));
			return null;
		case RilaiotmqttPackage.BROKERMQTT___UNSUBSCRIBE__STRING_STRING:
			unsubscribe((String) arguments.get(0), (String) arguments.get(1));
			return null;
		case RilaiotmqttPackage.BROKERMQTT___ARMAZENA_MENSAGEM__STRING_STRING:
			armazena_Mensagem((String) arguments.get(0), (String) arguments.get(1));
			return null;
		case RilaiotmqttPackage.BROKERMQTT___RECUPERA_MENSAGEM__STRING_STRING:
			recupera_Mensagem((String) arguments.get(0), (String) arguments.get(1));
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (ip: ");
		result.append(ip);
		result.append(')');
		return result.toString();
	}

} //brokermqttImpl
