/**
 */
package rilaiotmqtt;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>assinante</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link rilaiotmqtt.assinante#getIp_origem <em>Ip origem</em>}</li>
 *   <li>{@link rilaiotmqtt.assinante#getTopico <em>Topico</em>}</li>
 * </ul>
 *
 * @see rilaiotmqtt.RilaiotmqttPackage#getassinante()
 * @model
 * @generated
 */
public interface assinante extends EObject {
	/**
	 * Returns the value of the '<em><b>Ip origem</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ip origem</em>' attribute.
	 * @see #setIp_origem(String)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getassinante_Ip_origem()
	 * @model required="true"
	 * @generated
	 */
	String getIp_origem();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.assinante#getIp_origem <em>Ip origem</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ip origem</em>' attribute.
	 * @see #getIp_origem()
	 * @generated
	 */
	void setIp_origem(String value);

	/**
	 * Returns the value of the '<em><b>Topico</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Topico</em>' attribute.
	 * @see #setTopico(String)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getassinante_Topico()
	 * @model required="true"
	 * @generated
	 */
	String getTopico();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.assinante#getTopico <em>Topico</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Topico</em>' attribute.
	 * @see #getTopico()
	 * @generated
	 */
	void setTopico(String value);

} // assinante
