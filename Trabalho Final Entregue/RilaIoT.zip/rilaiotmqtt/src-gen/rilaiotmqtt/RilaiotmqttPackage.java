/**
 */
package rilaiotmqtt;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see rilaiotmqtt.RilaiotmqttFactory
 * @model kind="package"
 * @generated
 */
public interface RilaiotmqttPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "rilaiotmqtt";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/rilaiotmqtt";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "rilaiotmqtt";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	RilaiotmqttPackage eINSTANCE = rilaiotmqtt.impl.RilaiotmqttPackageImpl.init();

	/**
	 * The meta object id for the '{@link rilaiotmqtt.impl.aplicacaoImpl <em>aplicacao</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see rilaiotmqtt.impl.aplicacaoImpl
	 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getaplicacao()
	 * @generated
	 */
	int APLICACAO = 0;

	/**
	 * The feature id for the '<em><b>Nome</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int APLICACAO__NOME = 0;

	/**
	 * The feature id for the '<em><b>Brokermqtt</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int APLICACAO__BROKERMQTT = 1;

	/**
	 * The feature id for the '<em><b>Tv</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int APLICACAO__TV = 2;

	/**
	 * The feature id for the '<em><b>Geladeira</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int APLICACAO__GELADEIRA = 3;

	/**
	 * The number of structural features of the '<em>aplicacao</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int APLICACAO_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>aplicacao</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int APLICACAO_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link rilaiotmqtt.impl.geladeiraImpl <em>geladeira</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see rilaiotmqtt.impl.geladeiraImpl
	 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getgeladeira()
	 * @generated
	 */
	int GELADEIRA = 1;

	/**
	 * The feature id for the '<em><b>Ip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GELADEIRA__IP = 0;

	/**
	 * The feature id for the '<em><b>Temperatura</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GELADEIRA__TEMPERATURA = 1;

	/**
	 * The feature id for the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GELADEIRA__STATUS = 2;

	/**
	 * The feature id for the '<em><b>Cloud geladeira</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GELADEIRA__CLOUD_GELADEIRA = 3;

	/**
	 * The feature id for the '<em><b>Sensor geladeira</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GELADEIRA__SENSOR_GELADEIRA = 4;

	/**
	 * The feature id for the '<em><b>Atuador geladeira</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GELADEIRA__ATUADOR_GELADEIRA = 5;

	/**
	 * The number of structural features of the '<em>geladeira</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GELADEIRA_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>geladeira</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GELADEIRA_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link rilaiotmqtt.impl.tvImpl <em>tv</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see rilaiotmqtt.impl.tvImpl
	 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#gettv()
	 * @generated
	 */
	int TV = 2;

	/**
	 * The feature id for the '<em><b>Ip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TV__IP = 0;

	/**
	 * The feature id for the '<em><b>Canal</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TV__CANAL = 1;

	/**
	 * The feature id for the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TV__STATUS = 2;

	/**
	 * The feature id for the '<em><b>Cloud tv</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TV__CLOUD_TV = 3;

	/**
	 * The feature id for the '<em><b>Sensor tv</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TV__SENSOR_TV = 4;

	/**
	 * The feature id for the '<em><b>Atuador tv</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TV__ATUADOR_TV = 5;

	/**
	 * The number of structural features of the '<em>tv</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TV_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>tv</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TV_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link rilaiotmqtt.impl.brokermqttImpl <em>brokermqtt</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see rilaiotmqtt.impl.brokermqttImpl
	 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getbrokermqtt()
	 * @generated
	 */
	int BROKERMQTT = 3;

	/**
	 * The feature id for the '<em><b>Ip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BROKERMQTT__IP = 0;

	/**
	 * The feature id for the '<em><b>Mensagem</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BROKERMQTT__MENSAGEM = 1;

	/**
	 * The feature id for the '<em><b>Assinante</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BROKERMQTT__ASSINANTE = 2;

	/**
	 * The number of structural features of the '<em>brokermqtt</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BROKERMQTT_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Subscribe</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BROKERMQTT___SUBSCRIBE__STRING_STRING = 0;

	/**
	 * The operation id for the '<em>Publish</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BROKERMQTT___PUBLISH__STRING_STRING = 1;

	/**
	 * The operation id for the '<em>Unsubscribe</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BROKERMQTT___UNSUBSCRIBE__STRING_STRING = 2;

	/**
	 * The operation id for the '<em>Armazena Mensagem</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BROKERMQTT___ARMAZENA_MENSAGEM__STRING_STRING = 3;

	/**
	 * The operation id for the '<em>Recupera Mensagem</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BROKERMQTT___RECUPERA_MENSAGEM__STRING_STRING = 4;

	/**
	 * The number of operations of the '<em>brokermqtt</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BROKERMQTT_OPERATION_COUNT = 5;

	/**
	 * The meta object id for the '{@link rilaiotmqtt.impl.mensagemImpl <em>mensagem</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see rilaiotmqtt.impl.mensagemImpl
	 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getmensagem()
	 * @generated
	 */
	int MENSAGEM = 4;

	/**
	 * The feature id for the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MENSAGEM__STATUS = 0;

	/**
	 * The feature id for the '<em><b>Mensagem</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MENSAGEM__MENSAGEM = 1;

	/**
	 * The feature id for the '<em><b>Topico</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MENSAGEM__TOPICO = 2;

	/**
	 * The feature id for the '<em><b>Ip origem</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MENSAGEM__IP_ORIGEM = 3;

	/**
	 * The number of structural features of the '<em>mensagem</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MENSAGEM_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>mensagem</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MENSAGEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link rilaiotmqtt.impl.assinanteImpl <em>assinante</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see rilaiotmqtt.impl.assinanteImpl
	 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getassinante()
	 * @generated
	 */
	int ASSINANTE = 5;

	/**
	 * The feature id for the '<em><b>Ip origem</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSINANTE__IP_ORIGEM = 0;

	/**
	 * The feature id for the '<em><b>Topico</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSINANTE__TOPICO = 1;

	/**
	 * The number of structural features of the '<em>assinante</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSINANTE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>assinante</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSINANTE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link rilaiotmqtt.impl.cloudImpl <em>cloud</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see rilaiotmqtt.impl.cloudImpl
	 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getcloud()
	 * @generated
	 */
	int CLOUD = 6;

	/**
	 * The feature id for the '<em><b>Canal</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__CANAL = 0;

	/**
	 * The feature id for the '<em><b>Ip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__IP = 1;

	/**
	 * The feature id for the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__STATUS = 2;

	/**
	 * The feature id for the '<em><b>Temperatura</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__TEMPERATURA = 3;

	/**
	 * The number of structural features of the '<em>cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FEATURE_COUNT = 4;

	/**
	 * The operation id for the '<em>Recupera Canal</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD___RECUPERA_CANAL__STRING_INT = 0;

	/**
	 * The operation id for the '<em>Armazena Temperatura</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD___ARMAZENA_TEMPERATURA__STRING_FLOAT = 1;

	/**
	 * The operation id for the '<em>Armazena Status</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD___ARMAZENA_STATUS__STRING_BOOLEAN = 2;

	/**
	 * The operation id for the '<em>Armazena Canal</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD___ARMAZENA_CANAL__STRING_INT = 3;

	/**
	 * The operation id for the '<em>Recupera Status</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD___RECUPERA_STATUS__STRING_BOOLEAN = 4;

	/**
	 * The operation id for the '<em>Recupera Temperatura</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD___RECUPERA_TEMPERATURA__STRING_FLOAT = 5;

	/**
	 * The number of operations of the '<em>cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_OPERATION_COUNT = 6;

	/**
	 * The meta object id for the '{@link rilaiotmqtt.impl.sensorImpl <em>sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see rilaiotmqtt.impl.sensorImpl
	 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getsensor()
	 * @generated
	 */
	int SENSOR = 7;

	/**
	 * The feature id for the '<em><b>Ip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__IP = 0;

	/**
	 * The number of structural features of the '<em>sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Informa Status</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR___INFORMA_STATUS__STRING_BOOLEAN = 0;

	/**
	 * The operation id for the '<em>Informa Temperatura</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR___INFORMA_TEMPERATURA__STRING_FLOAT = 1;

	/**
	 * The operation id for the '<em>Informa Canal</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR___INFORMA_CANAL__STRING_INT = 2;

	/**
	 * The operation id for the '<em>Publish</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR___PUBLISH__STRING_STRING = 3;

	/**
	 * The number of operations of the '<em>sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_OPERATION_COUNT = 4;

	/**
	 * The meta object id for the '{@link rilaiotmqtt.impl.atuadorImpl <em>atuador</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see rilaiotmqtt.impl.atuadorImpl
	 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getatuador()
	 * @generated
	 */
	int ATUADOR = 8;

	/**
	 * The feature id for the '<em><b>Ip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATUADOR__IP = 0;

	/**
	 * The number of structural features of the '<em>atuador</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATUADOR_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Muda Canal</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATUADOR___MUDA_CANAL__STRING_INT = 0;

	/**
	 * The operation id for the '<em>Muda Status</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATUADOR___MUDA_STATUS__STRING_BOOLEAN = 1;

	/**
	 * The operation id for the '<em>Muda Temperatura</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATUADOR___MUDA_TEMPERATURA__STRING_FLOAT = 2;

	/**
	 * The operation id for the '<em>Publish</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATUADOR___PUBLISH__STRING_STRING = 3;

	/**
	 * The number of operations of the '<em>atuador</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATUADOR_OPERATION_COUNT = 4;

	/**
	 * Returns the meta object for class '{@link rilaiotmqtt.aplicacao <em>aplicacao</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>aplicacao</em>'.
	 * @see rilaiotmqtt.aplicacao
	 * @generated
	 */
	EClass getaplicacao();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.aplicacao#getNome <em>Nome</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nome</em>'.
	 * @see rilaiotmqtt.aplicacao#getNome()
	 * @see #getaplicacao()
	 * @generated
	 */
	EAttribute getaplicacao_Nome();

	/**
	 * Returns the meta object for the containment reference '{@link rilaiotmqtt.aplicacao#getBrokermqtt <em>Brokermqtt</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Brokermqtt</em>'.
	 * @see rilaiotmqtt.aplicacao#getBrokermqtt()
	 * @see #getaplicacao()
	 * @generated
	 */
	EReference getaplicacao_Brokermqtt();

	/**
	 * Returns the meta object for the containment reference list '{@link rilaiotmqtt.aplicacao#getTv <em>Tv</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Tv</em>'.
	 * @see rilaiotmqtt.aplicacao#getTv()
	 * @see #getaplicacao()
	 * @generated
	 */
	EReference getaplicacao_Tv();

	/**
	 * Returns the meta object for the containment reference list '{@link rilaiotmqtt.aplicacao#getGeladeira <em>Geladeira</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Geladeira</em>'.
	 * @see rilaiotmqtt.aplicacao#getGeladeira()
	 * @see #getaplicacao()
	 * @generated
	 */
	EReference getaplicacao_Geladeira();

	/**
	 * Returns the meta object for class '{@link rilaiotmqtt.geladeira <em>geladeira</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>geladeira</em>'.
	 * @see rilaiotmqtt.geladeira
	 * @generated
	 */
	EClass getgeladeira();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.geladeira#getIp <em>Ip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ip</em>'.
	 * @see rilaiotmqtt.geladeira#getIp()
	 * @see #getgeladeira()
	 * @generated
	 */
	EAttribute getgeladeira_Ip();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.geladeira#getTemperatura <em>Temperatura</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Temperatura</em>'.
	 * @see rilaiotmqtt.geladeira#getTemperatura()
	 * @see #getgeladeira()
	 * @generated
	 */
	EAttribute getgeladeira_Temperatura();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.geladeira#isStatus <em>Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Status</em>'.
	 * @see rilaiotmqtt.geladeira#isStatus()
	 * @see #getgeladeira()
	 * @generated
	 */
	EAttribute getgeladeira_Status();

	/**
	 * Returns the meta object for the containment reference list '{@link rilaiotmqtt.geladeira#getCloud_geladeira <em>Cloud geladeira</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cloud geladeira</em>'.
	 * @see rilaiotmqtt.geladeira#getCloud_geladeira()
	 * @see #getgeladeira()
	 * @generated
	 */
	EReference getgeladeira_Cloud_geladeira();

	/**
	 * Returns the meta object for the containment reference list '{@link rilaiotmqtt.geladeira#getSensor_geladeira <em>Sensor geladeira</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sensor geladeira</em>'.
	 * @see rilaiotmqtt.geladeira#getSensor_geladeira()
	 * @see #getgeladeira()
	 * @generated
	 */
	EReference getgeladeira_Sensor_geladeira();

	/**
	 * Returns the meta object for the containment reference list '{@link rilaiotmqtt.geladeira#getAtuador_geladeira <em>Atuador geladeira</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Atuador geladeira</em>'.
	 * @see rilaiotmqtt.geladeira#getAtuador_geladeira()
	 * @see #getgeladeira()
	 * @generated
	 */
	EReference getgeladeira_Atuador_geladeira();

	/**
	 * Returns the meta object for class '{@link rilaiotmqtt.tv <em>tv</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>tv</em>'.
	 * @see rilaiotmqtt.tv
	 * @generated
	 */
	EClass gettv();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.tv#getIp <em>Ip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ip</em>'.
	 * @see rilaiotmqtt.tv#getIp()
	 * @see #gettv()
	 * @generated
	 */
	EAttribute gettv_Ip();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.tv#getCanal <em>Canal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Canal</em>'.
	 * @see rilaiotmqtt.tv#getCanal()
	 * @see #gettv()
	 * @generated
	 */
	EAttribute gettv_Canal();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.tv#isStatus <em>Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Status</em>'.
	 * @see rilaiotmqtt.tv#isStatus()
	 * @see #gettv()
	 * @generated
	 */
	EAttribute gettv_Status();

	/**
	 * Returns the meta object for the containment reference list '{@link rilaiotmqtt.tv#getCloud_tv <em>Cloud tv</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cloud tv</em>'.
	 * @see rilaiotmqtt.tv#getCloud_tv()
	 * @see #gettv()
	 * @generated
	 */
	EReference gettv_Cloud_tv();

	/**
	 * Returns the meta object for the containment reference list '{@link rilaiotmqtt.tv#getSensor_tv <em>Sensor tv</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sensor tv</em>'.
	 * @see rilaiotmqtt.tv#getSensor_tv()
	 * @see #gettv()
	 * @generated
	 */
	EReference gettv_Sensor_tv();

	/**
	 * Returns the meta object for the containment reference list '{@link rilaiotmqtt.tv#getAtuador_tv <em>Atuador tv</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Atuador tv</em>'.
	 * @see rilaiotmqtt.tv#getAtuador_tv()
	 * @see #gettv()
	 * @generated
	 */
	EReference gettv_Atuador_tv();

	/**
	 * Returns the meta object for class '{@link rilaiotmqtt.brokermqtt <em>brokermqtt</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>brokermqtt</em>'.
	 * @see rilaiotmqtt.brokermqtt
	 * @generated
	 */
	EClass getbrokermqtt();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.brokermqtt#getIp <em>Ip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ip</em>'.
	 * @see rilaiotmqtt.brokermqtt#getIp()
	 * @see #getbrokermqtt()
	 * @generated
	 */
	EAttribute getbrokermqtt_Ip();

	/**
	 * Returns the meta object for the containment reference list '{@link rilaiotmqtt.brokermqtt#getMensagem <em>Mensagem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Mensagem</em>'.
	 * @see rilaiotmqtt.brokermqtt#getMensagem()
	 * @see #getbrokermqtt()
	 * @generated
	 */
	EReference getbrokermqtt_Mensagem();

	/**
	 * Returns the meta object for the containment reference list '{@link rilaiotmqtt.brokermqtt#getAssinante <em>Assinante</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Assinante</em>'.
	 * @see rilaiotmqtt.brokermqtt#getAssinante()
	 * @see #getbrokermqtt()
	 * @generated
	 */
	EReference getbrokermqtt_Assinante();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.brokermqtt#subscribe(java.lang.String, java.lang.String) <em>Subscribe</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Subscribe</em>' operation.
	 * @see rilaiotmqtt.brokermqtt#subscribe(java.lang.String, java.lang.String)
	 * @generated
	 */
	EOperation getbrokermqtt__Subscribe__String_String();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.brokermqtt#publish(java.lang.String, java.lang.String) <em>Publish</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Publish</em>' operation.
	 * @see rilaiotmqtt.brokermqtt#publish(java.lang.String, java.lang.String)
	 * @generated
	 */
	EOperation getbrokermqtt__Publish__String_String();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.brokermqtt#unsubscribe(java.lang.String, java.lang.String) <em>Unsubscribe</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Unsubscribe</em>' operation.
	 * @see rilaiotmqtt.brokermqtt#unsubscribe(java.lang.String, java.lang.String)
	 * @generated
	 */
	EOperation getbrokermqtt__Unsubscribe__String_String();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.brokermqtt#armazena_Mensagem(java.lang.String, java.lang.String) <em>Armazena Mensagem</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Armazena Mensagem</em>' operation.
	 * @see rilaiotmqtt.brokermqtt#armazena_Mensagem(java.lang.String, java.lang.String)
	 * @generated
	 */
	EOperation getbrokermqtt__Armazena_Mensagem__String_String();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.brokermqtt#recupera_Mensagem(java.lang.String, java.lang.String) <em>Recupera Mensagem</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Recupera Mensagem</em>' operation.
	 * @see rilaiotmqtt.brokermqtt#recupera_Mensagem(java.lang.String, java.lang.String)
	 * @generated
	 */
	EOperation getbrokermqtt__Recupera_Mensagem__String_String();

	/**
	 * Returns the meta object for class '{@link rilaiotmqtt.mensagem <em>mensagem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>mensagem</em>'.
	 * @see rilaiotmqtt.mensagem
	 * @generated
	 */
	EClass getmensagem();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.mensagem#getStatus <em>Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Status</em>'.
	 * @see rilaiotmqtt.mensagem#getStatus()
	 * @see #getmensagem()
	 * @generated
	 */
	EAttribute getmensagem_Status();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.mensagem#getMensagem <em>Mensagem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mensagem</em>'.
	 * @see rilaiotmqtt.mensagem#getMensagem()
	 * @see #getmensagem()
	 * @generated
	 */
	EAttribute getmensagem_Mensagem();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.mensagem#getTopico <em>Topico</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Topico</em>'.
	 * @see rilaiotmqtt.mensagem#getTopico()
	 * @see #getmensagem()
	 * @generated
	 */
	EAttribute getmensagem_Topico();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.mensagem#getIp_origem <em>Ip origem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ip origem</em>'.
	 * @see rilaiotmqtt.mensagem#getIp_origem()
	 * @see #getmensagem()
	 * @generated
	 */
	EAttribute getmensagem_Ip_origem();

	/**
	 * Returns the meta object for class '{@link rilaiotmqtt.assinante <em>assinante</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>assinante</em>'.
	 * @see rilaiotmqtt.assinante
	 * @generated
	 */
	EClass getassinante();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.assinante#getIp_origem <em>Ip origem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ip origem</em>'.
	 * @see rilaiotmqtt.assinante#getIp_origem()
	 * @see #getassinante()
	 * @generated
	 */
	EAttribute getassinante_Ip_origem();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.assinante#getTopico <em>Topico</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Topico</em>'.
	 * @see rilaiotmqtt.assinante#getTopico()
	 * @see #getassinante()
	 * @generated
	 */
	EAttribute getassinante_Topico();

	/**
	 * Returns the meta object for class '{@link rilaiotmqtt.cloud <em>cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>cloud</em>'.
	 * @see rilaiotmqtt.cloud
	 * @generated
	 */
	EClass getcloud();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.cloud#getCanal <em>Canal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Canal</em>'.
	 * @see rilaiotmqtt.cloud#getCanal()
	 * @see #getcloud()
	 * @generated
	 */
	EAttribute getcloud_Canal();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.cloud#getIp <em>Ip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ip</em>'.
	 * @see rilaiotmqtt.cloud#getIp()
	 * @see #getcloud()
	 * @generated
	 */
	EAttribute getcloud_Ip();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.cloud#isStatus <em>Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Status</em>'.
	 * @see rilaiotmqtt.cloud#isStatus()
	 * @see #getcloud()
	 * @generated
	 */
	EAttribute getcloud_Status();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.cloud#getTemperatura <em>Temperatura</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Temperatura</em>'.
	 * @see rilaiotmqtt.cloud#getTemperatura()
	 * @see #getcloud()
	 * @generated
	 */
	EAttribute getcloud_Temperatura();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.cloud#recupera_Canal(java.lang.String, int) <em>Recupera Canal</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Recupera Canal</em>' operation.
	 * @see rilaiotmqtt.cloud#recupera_Canal(java.lang.String, int)
	 * @generated
	 */
	EOperation getcloud__Recupera_Canal__String_int();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.cloud#armazena_Temperatura(java.lang.String, float) <em>Armazena Temperatura</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Armazena Temperatura</em>' operation.
	 * @see rilaiotmqtt.cloud#armazena_Temperatura(java.lang.String, float)
	 * @generated
	 */
	EOperation getcloud__Armazena_Temperatura__String_float();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.cloud#armazena_Status(java.lang.String, boolean) <em>Armazena Status</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Armazena Status</em>' operation.
	 * @see rilaiotmqtt.cloud#armazena_Status(java.lang.String, boolean)
	 * @generated
	 */
	EOperation getcloud__Armazena_Status__String_boolean();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.cloud#armazena_Canal(java.lang.String, int) <em>Armazena Canal</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Armazena Canal</em>' operation.
	 * @see rilaiotmqtt.cloud#armazena_Canal(java.lang.String, int)
	 * @generated
	 */
	EOperation getcloud__Armazena_Canal__String_int();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.cloud#recupera_Status(java.lang.String, boolean) <em>Recupera Status</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Recupera Status</em>' operation.
	 * @see rilaiotmqtt.cloud#recupera_Status(java.lang.String, boolean)
	 * @generated
	 */
	EOperation getcloud__Recupera_Status__String_boolean();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.cloud#recupera_Temperatura(java.lang.String, float) <em>Recupera Temperatura</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Recupera Temperatura</em>' operation.
	 * @see rilaiotmqtt.cloud#recupera_Temperatura(java.lang.String, float)
	 * @generated
	 */
	EOperation getcloud__Recupera_Temperatura__String_float();

	/**
	 * Returns the meta object for class '{@link rilaiotmqtt.sensor <em>sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>sensor</em>'.
	 * @see rilaiotmqtt.sensor
	 * @generated
	 */
	EClass getsensor();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.sensor#getIp <em>Ip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ip</em>'.
	 * @see rilaiotmqtt.sensor#getIp()
	 * @see #getsensor()
	 * @generated
	 */
	EAttribute getsensor_Ip();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.sensor#informa_Status(java.lang.String, boolean) <em>Informa Status</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Informa Status</em>' operation.
	 * @see rilaiotmqtt.sensor#informa_Status(java.lang.String, boolean)
	 * @generated
	 */
	EOperation getsensor__Informa_Status__String_boolean();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.sensor#informa_Temperatura(java.lang.String, float) <em>Informa Temperatura</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Informa Temperatura</em>' operation.
	 * @see rilaiotmqtt.sensor#informa_Temperatura(java.lang.String, float)
	 * @generated
	 */
	EOperation getsensor__Informa_Temperatura__String_float();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.sensor#informa_Canal(java.lang.String, int) <em>Informa Canal</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Informa Canal</em>' operation.
	 * @see rilaiotmqtt.sensor#informa_Canal(java.lang.String, int)
	 * @generated
	 */
	EOperation getsensor__Informa_Canal__String_int();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.sensor#publish(java.lang.String, java.lang.String) <em>Publish</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Publish</em>' operation.
	 * @see rilaiotmqtt.sensor#publish(java.lang.String, java.lang.String)
	 * @generated
	 */
	EOperation getsensor__Publish__String_String();

	/**
	 * Returns the meta object for class '{@link rilaiotmqtt.atuador <em>atuador</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>atuador</em>'.
	 * @see rilaiotmqtt.atuador
	 * @generated
	 */
	EClass getatuador();

	/**
	 * Returns the meta object for the attribute '{@link rilaiotmqtt.atuador#getIp <em>Ip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ip</em>'.
	 * @see rilaiotmqtt.atuador#getIp()
	 * @see #getatuador()
	 * @generated
	 */
	EAttribute getatuador_Ip();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.atuador#muda_Canal(java.lang.String, int) <em>Muda Canal</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Muda Canal</em>' operation.
	 * @see rilaiotmqtt.atuador#muda_Canal(java.lang.String, int)
	 * @generated
	 */
	EOperation getatuador__Muda_Canal__String_int();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.atuador#muda_Status(java.lang.String, boolean) <em>Muda Status</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Muda Status</em>' operation.
	 * @see rilaiotmqtt.atuador#muda_Status(java.lang.String, boolean)
	 * @generated
	 */
	EOperation getatuador__Muda_Status__String_boolean();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.atuador#muda_Temperatura(java.lang.String, float) <em>Muda Temperatura</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Muda Temperatura</em>' operation.
	 * @see rilaiotmqtt.atuador#muda_Temperatura(java.lang.String, float)
	 * @generated
	 */
	EOperation getatuador__Muda_Temperatura__String_float();

	/**
	 * Returns the meta object for the '{@link rilaiotmqtt.atuador#publish(java.lang.String, java.lang.String) <em>Publish</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Publish</em>' operation.
	 * @see rilaiotmqtt.atuador#publish(java.lang.String, java.lang.String)
	 * @generated
	 */
	EOperation getatuador__Publish__String_String();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	RilaiotmqttFactory getRilaiotmqttFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link rilaiotmqtt.impl.aplicacaoImpl <em>aplicacao</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see rilaiotmqtt.impl.aplicacaoImpl
		 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getaplicacao()
		 * @generated
		 */
		EClass APLICACAO = eINSTANCE.getaplicacao();

		/**
		 * The meta object literal for the '<em><b>Nome</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute APLICACAO__NOME = eINSTANCE.getaplicacao_Nome();

		/**
		 * The meta object literal for the '<em><b>Brokermqtt</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference APLICACAO__BROKERMQTT = eINSTANCE.getaplicacao_Brokermqtt();

		/**
		 * The meta object literal for the '<em><b>Tv</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference APLICACAO__TV = eINSTANCE.getaplicacao_Tv();

		/**
		 * The meta object literal for the '<em><b>Geladeira</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference APLICACAO__GELADEIRA = eINSTANCE.getaplicacao_Geladeira();

		/**
		 * The meta object literal for the '{@link rilaiotmqtt.impl.geladeiraImpl <em>geladeira</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see rilaiotmqtt.impl.geladeiraImpl
		 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getgeladeira()
		 * @generated
		 */
		EClass GELADEIRA = eINSTANCE.getgeladeira();

		/**
		 * The meta object literal for the '<em><b>Ip</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GELADEIRA__IP = eINSTANCE.getgeladeira_Ip();

		/**
		 * The meta object literal for the '<em><b>Temperatura</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GELADEIRA__TEMPERATURA = eINSTANCE.getgeladeira_Temperatura();

		/**
		 * The meta object literal for the '<em><b>Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GELADEIRA__STATUS = eINSTANCE.getgeladeira_Status();

		/**
		 * The meta object literal for the '<em><b>Cloud geladeira</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GELADEIRA__CLOUD_GELADEIRA = eINSTANCE.getgeladeira_Cloud_geladeira();

		/**
		 * The meta object literal for the '<em><b>Sensor geladeira</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GELADEIRA__SENSOR_GELADEIRA = eINSTANCE.getgeladeira_Sensor_geladeira();

		/**
		 * The meta object literal for the '<em><b>Atuador geladeira</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GELADEIRA__ATUADOR_GELADEIRA = eINSTANCE.getgeladeira_Atuador_geladeira();

		/**
		 * The meta object literal for the '{@link rilaiotmqtt.impl.tvImpl <em>tv</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see rilaiotmqtt.impl.tvImpl
		 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#gettv()
		 * @generated
		 */
		EClass TV = eINSTANCE.gettv();

		/**
		 * The meta object literal for the '<em><b>Ip</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TV__IP = eINSTANCE.gettv_Ip();

		/**
		 * The meta object literal for the '<em><b>Canal</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TV__CANAL = eINSTANCE.gettv_Canal();

		/**
		 * The meta object literal for the '<em><b>Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TV__STATUS = eINSTANCE.gettv_Status();

		/**
		 * The meta object literal for the '<em><b>Cloud tv</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TV__CLOUD_TV = eINSTANCE.gettv_Cloud_tv();

		/**
		 * The meta object literal for the '<em><b>Sensor tv</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TV__SENSOR_TV = eINSTANCE.gettv_Sensor_tv();

		/**
		 * The meta object literal for the '<em><b>Atuador tv</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TV__ATUADOR_TV = eINSTANCE.gettv_Atuador_tv();

		/**
		 * The meta object literal for the '{@link rilaiotmqtt.impl.brokermqttImpl <em>brokermqtt</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see rilaiotmqtt.impl.brokermqttImpl
		 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getbrokermqtt()
		 * @generated
		 */
		EClass BROKERMQTT = eINSTANCE.getbrokermqtt();

		/**
		 * The meta object literal for the '<em><b>Ip</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BROKERMQTT__IP = eINSTANCE.getbrokermqtt_Ip();

		/**
		 * The meta object literal for the '<em><b>Mensagem</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BROKERMQTT__MENSAGEM = eINSTANCE.getbrokermqtt_Mensagem();

		/**
		 * The meta object literal for the '<em><b>Assinante</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BROKERMQTT__ASSINANTE = eINSTANCE.getbrokermqtt_Assinante();

		/**
		 * The meta object literal for the '<em><b>Subscribe</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation BROKERMQTT___SUBSCRIBE__STRING_STRING = eINSTANCE.getbrokermqtt__Subscribe__String_String();

		/**
		 * The meta object literal for the '<em><b>Publish</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation BROKERMQTT___PUBLISH__STRING_STRING = eINSTANCE.getbrokermqtt__Publish__String_String();

		/**
		 * The meta object literal for the '<em><b>Unsubscribe</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation BROKERMQTT___UNSUBSCRIBE__STRING_STRING = eINSTANCE.getbrokermqtt__Unsubscribe__String_String();

		/**
		 * The meta object literal for the '<em><b>Armazena Mensagem</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation BROKERMQTT___ARMAZENA_MENSAGEM__STRING_STRING = eINSTANCE
				.getbrokermqtt__Armazena_Mensagem__String_String();

		/**
		 * The meta object literal for the '<em><b>Recupera Mensagem</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation BROKERMQTT___RECUPERA_MENSAGEM__STRING_STRING = eINSTANCE
				.getbrokermqtt__Recupera_Mensagem__String_String();

		/**
		 * The meta object literal for the '{@link rilaiotmqtt.impl.mensagemImpl <em>mensagem</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see rilaiotmqtt.impl.mensagemImpl
		 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getmensagem()
		 * @generated
		 */
		EClass MENSAGEM = eINSTANCE.getmensagem();

		/**
		 * The meta object literal for the '<em><b>Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MENSAGEM__STATUS = eINSTANCE.getmensagem_Status();

		/**
		 * The meta object literal for the '<em><b>Mensagem</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MENSAGEM__MENSAGEM = eINSTANCE.getmensagem_Mensagem();

		/**
		 * The meta object literal for the '<em><b>Topico</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MENSAGEM__TOPICO = eINSTANCE.getmensagem_Topico();

		/**
		 * The meta object literal for the '<em><b>Ip origem</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MENSAGEM__IP_ORIGEM = eINSTANCE.getmensagem_Ip_origem();

		/**
		 * The meta object literal for the '{@link rilaiotmqtt.impl.assinanteImpl <em>assinante</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see rilaiotmqtt.impl.assinanteImpl
		 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getassinante()
		 * @generated
		 */
		EClass ASSINANTE = eINSTANCE.getassinante();

		/**
		 * The meta object literal for the '<em><b>Ip origem</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSINANTE__IP_ORIGEM = eINSTANCE.getassinante_Ip_origem();

		/**
		 * The meta object literal for the '<em><b>Topico</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSINANTE__TOPICO = eINSTANCE.getassinante_Topico();

		/**
		 * The meta object literal for the '{@link rilaiotmqtt.impl.cloudImpl <em>cloud</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see rilaiotmqtt.impl.cloudImpl
		 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getcloud()
		 * @generated
		 */
		EClass CLOUD = eINSTANCE.getcloud();

		/**
		 * The meta object literal for the '<em><b>Canal</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD__CANAL = eINSTANCE.getcloud_Canal();

		/**
		 * The meta object literal for the '<em><b>Ip</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD__IP = eINSTANCE.getcloud_Ip();

		/**
		 * The meta object literal for the '<em><b>Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD__STATUS = eINSTANCE.getcloud_Status();

		/**
		 * The meta object literal for the '<em><b>Temperatura</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD__TEMPERATURA = eINSTANCE.getcloud_Temperatura();

		/**
		 * The meta object literal for the '<em><b>Recupera Canal</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CLOUD___RECUPERA_CANAL__STRING_INT = eINSTANCE.getcloud__Recupera_Canal__String_int();

		/**
		 * The meta object literal for the '<em><b>Armazena Temperatura</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CLOUD___ARMAZENA_TEMPERATURA__STRING_FLOAT = eINSTANCE
				.getcloud__Armazena_Temperatura__String_float();

		/**
		 * The meta object literal for the '<em><b>Armazena Status</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CLOUD___ARMAZENA_STATUS__STRING_BOOLEAN = eINSTANCE.getcloud__Armazena_Status__String_boolean();

		/**
		 * The meta object literal for the '<em><b>Armazena Canal</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CLOUD___ARMAZENA_CANAL__STRING_INT = eINSTANCE.getcloud__Armazena_Canal__String_int();

		/**
		 * The meta object literal for the '<em><b>Recupera Status</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CLOUD___RECUPERA_STATUS__STRING_BOOLEAN = eINSTANCE.getcloud__Recupera_Status__String_boolean();

		/**
		 * The meta object literal for the '<em><b>Recupera Temperatura</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CLOUD___RECUPERA_TEMPERATURA__STRING_FLOAT = eINSTANCE
				.getcloud__Recupera_Temperatura__String_float();

		/**
		 * The meta object literal for the '{@link rilaiotmqtt.impl.sensorImpl <em>sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see rilaiotmqtt.impl.sensorImpl
		 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getsensor()
		 * @generated
		 */
		EClass SENSOR = eINSTANCE.getsensor();

		/**
		 * The meta object literal for the '<em><b>Ip</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENSOR__IP = eINSTANCE.getsensor_Ip();

		/**
		 * The meta object literal for the '<em><b>Informa Status</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SENSOR___INFORMA_STATUS__STRING_BOOLEAN = eINSTANCE.getsensor__Informa_Status__String_boolean();

		/**
		 * The meta object literal for the '<em><b>Informa Temperatura</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SENSOR___INFORMA_TEMPERATURA__STRING_FLOAT = eINSTANCE
				.getsensor__Informa_Temperatura__String_float();

		/**
		 * The meta object literal for the '<em><b>Informa Canal</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SENSOR___INFORMA_CANAL__STRING_INT = eINSTANCE.getsensor__Informa_Canal__String_int();

		/**
		 * The meta object literal for the '<em><b>Publish</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SENSOR___PUBLISH__STRING_STRING = eINSTANCE.getsensor__Publish__String_String();

		/**
		 * The meta object literal for the '{@link rilaiotmqtt.impl.atuadorImpl <em>atuador</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see rilaiotmqtt.impl.atuadorImpl
		 * @see rilaiotmqtt.impl.RilaiotmqttPackageImpl#getatuador()
		 * @generated
		 */
		EClass ATUADOR = eINSTANCE.getatuador();

		/**
		 * The meta object literal for the '<em><b>Ip</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATUADOR__IP = eINSTANCE.getatuador_Ip();

		/**
		 * The meta object literal for the '<em><b>Muda Canal</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ATUADOR___MUDA_CANAL__STRING_INT = eINSTANCE.getatuador__Muda_Canal__String_int();

		/**
		 * The meta object literal for the '<em><b>Muda Status</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ATUADOR___MUDA_STATUS__STRING_BOOLEAN = eINSTANCE.getatuador__Muda_Status__String_boolean();

		/**
		 * The meta object literal for the '<em><b>Muda Temperatura</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ATUADOR___MUDA_TEMPERATURA__STRING_FLOAT = eINSTANCE.getatuador__Muda_Temperatura__String_float();

		/**
		 * The meta object literal for the '<em><b>Publish</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ATUADOR___PUBLISH__STRING_STRING = eINSTANCE.getatuador__Publish__String_String();

	}

} //RilaiotmqttPackage
