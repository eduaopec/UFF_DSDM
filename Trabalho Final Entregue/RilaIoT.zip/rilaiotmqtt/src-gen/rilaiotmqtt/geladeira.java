/**
 */
package rilaiotmqtt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>geladeira</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link rilaiotmqtt.geladeira#getIp <em>Ip</em>}</li>
 *   <li>{@link rilaiotmqtt.geladeira#getTemperatura <em>Temperatura</em>}</li>
 *   <li>{@link rilaiotmqtt.geladeira#isStatus <em>Status</em>}</li>
 *   <li>{@link rilaiotmqtt.geladeira#getCloud_geladeira <em>Cloud geladeira</em>}</li>
 *   <li>{@link rilaiotmqtt.geladeira#getSensor_geladeira <em>Sensor geladeira</em>}</li>
 *   <li>{@link rilaiotmqtt.geladeira#getAtuador_geladeira <em>Atuador geladeira</em>}</li>
 * </ul>
 *
 * @see rilaiotmqtt.RilaiotmqttPackage#getgeladeira()
 * @model
 * @generated
 */
public interface geladeira extends EObject {
	/**
	 * Returns the value of the '<em><b>Ip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ip</em>' attribute.
	 * @see #setIp(String)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getgeladeira_Ip()
	 * @model required="true"
	 * @generated
	 */
	String getIp();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.geladeira#getIp <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ip</em>' attribute.
	 * @see #getIp()
	 * @generated
	 */
	void setIp(String value);

	/**
	 * Returns the value of the '<em><b>Temperatura</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Temperatura</em>' attribute.
	 * @see #setTemperatura(float)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getgeladeira_Temperatura()
	 * @model required="true"
	 * @generated
	 */
	float getTemperatura();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.geladeira#getTemperatura <em>Temperatura</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Temperatura</em>' attribute.
	 * @see #getTemperatura()
	 * @generated
	 */
	void setTemperatura(float value);

	/**
	 * Returns the value of the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status</em>' attribute.
	 * @see #setStatus(boolean)
	 * @see rilaiotmqtt.RilaiotmqttPackage#getgeladeira_Status()
	 * @model required="true"
	 * @generated
	 */
	boolean isStatus();

	/**
	 * Sets the value of the '{@link rilaiotmqtt.geladeira#isStatus <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status</em>' attribute.
	 * @see #isStatus()
	 * @generated
	 */
	void setStatus(boolean value);

	/**
	 * Returns the value of the '<em><b>Cloud geladeira</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiotmqtt.cloud}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cloud geladeira</em>' containment reference list.
	 * @see rilaiotmqtt.RilaiotmqttPackage#getgeladeira_Cloud_geladeira()
	 * @model containment="true"
	 * @generated
	 */
	EList<cloud> getCloud_geladeira();

	/**
	 * Returns the value of the '<em><b>Sensor geladeira</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiotmqtt.sensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sensor geladeira</em>' containment reference list.
	 * @see rilaiotmqtt.RilaiotmqttPackage#getgeladeira_Sensor_geladeira()
	 * @model containment="true"
	 * @generated
	 */
	EList<sensor> getSensor_geladeira();

	/**
	 * Returns the value of the '<em><b>Atuador geladeira</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiotmqtt.atuador}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Atuador geladeira</em>' containment reference list.
	 * @see rilaiotmqtt.RilaiotmqttPackage#getgeladeira_Atuador_geladeira()
	 * @model containment="true"
	 * @generated
	 */
	EList<atuador> getAtuador_geladeira();

} // geladeira
