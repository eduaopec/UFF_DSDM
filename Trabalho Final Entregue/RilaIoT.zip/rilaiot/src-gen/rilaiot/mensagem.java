/**
 */
package rilaiot;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>mensagem</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link rilaiot.mensagem#getIp_origem <em>Ip origem</em>}</li>
 *   <li>{@link rilaiot.mensagem#getTopico <em>Topico</em>}</li>
 *   <li>{@link rilaiot.mensagem#getMensagem <em>Mensagem</em>}</li>
 *   <li>{@link rilaiot.mensagem#isStatus <em>Status</em>}</li>
 * </ul>
 *
 * @see rilaiot.RilaiotPackage#getmensagem()
 * @model
 * @generated
 */
public interface mensagem extends EObject {
	/**
	 * Returns the value of the '<em><b>Ip origem</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ip origem</em>' attribute.
	 * @see #setIp_origem(String)
	 * @see rilaiot.RilaiotPackage#getmensagem_Ip_origem()
	 * @model required="true"
	 * @generated
	 */
	String getIp_origem();

	/**
	 * Sets the value of the '{@link rilaiot.mensagem#getIp_origem <em>Ip origem</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ip origem</em>' attribute.
	 * @see #getIp_origem()
	 * @generated
	 */
	void setIp_origem(String value);

	/**
	 * Returns the value of the '<em><b>Topico</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Topico</em>' attribute.
	 * @see #setTopico(String)
	 * @see rilaiot.RilaiotPackage#getmensagem_Topico()
	 * @model required="true"
	 * @generated
	 */
	String getTopico();

	/**
	 * Sets the value of the '{@link rilaiot.mensagem#getTopico <em>Topico</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Topico</em>' attribute.
	 * @see #getTopico()
	 * @generated
	 */
	void setTopico(String value);

	/**
	 * Returns the value of the '<em><b>Mensagem</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mensagem</em>' attribute.
	 * @see #setMensagem(String)
	 * @see rilaiot.RilaiotPackage#getmensagem_Mensagem()
	 * @model required="true"
	 * @generated
	 */
	String getMensagem();

	/**
	 * Sets the value of the '{@link rilaiot.mensagem#getMensagem <em>Mensagem</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Mensagem</em>' attribute.
	 * @see #getMensagem()
	 * @generated
	 */
	void setMensagem(String value);

	/**
	 * Returns the value of the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status</em>' attribute.
	 * @see #setStatus(boolean)
	 * @see rilaiot.RilaiotPackage#getmensagem_Status()
	 * @model required="true"
	 * @generated
	 */
	boolean isStatus();

	/**
	 * Sets the value of the '{@link rilaiot.mensagem#isStatus <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status</em>' attribute.
	 * @see #isStatus()
	 * @generated
	 */
	void setStatus(boolean value);

} // mensagem
