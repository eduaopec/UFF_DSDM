/**
 */
package rilaiot;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see rilaiot.RilaiotPackage
 * @generated
 */
public interface RilaiotFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	RilaiotFactory eINSTANCE = rilaiot.impl.RilaiotFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>aplicacao</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>aplicacao</em>'.
	 * @generated
	 */
	aplicacao createaplicacao();

	/**
	 * Returns a new object of class '<em>geladeira</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>geladeira</em>'.
	 * @generated
	 */
	geladeira creategeladeira();

	/**
	 * Returns a new object of class '<em>tv</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>tv</em>'.
	 * @generated
	 */
	tv createtv();

	/**
	 * Returns a new object of class '<em>mensageria</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>mensageria</em>'.
	 * @generated
	 */
	mensageria createmensageria();

	/**
	 * Returns a new object of class '<em>cloud</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>cloud</em>'.
	 * @generated
	 */
	cloud createcloud();

	/**
	 * Returns a new object of class '<em>sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>sensor</em>'.
	 * @generated
	 */
	sensor createsensor();

	/**
	 * Returns a new object of class '<em>atuador</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>atuador</em>'.
	 * @generated
	 */
	atuador createatuador();

	/**
	 * Returns a new object of class '<em>mensagem</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>mensagem</em>'.
	 * @generated
	 */
	mensagem createmensagem();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	RilaiotPackage getRilaiotPackage();

} //RilaiotFactory
