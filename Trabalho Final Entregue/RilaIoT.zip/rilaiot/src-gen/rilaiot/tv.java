/**
 */
package rilaiot;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>tv</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link rilaiot.tv#getIp <em>Ip</em>}</li>
 *   <li>{@link rilaiot.tv#getCanal <em>Canal</em>}</li>
 *   <li>{@link rilaiot.tv#isStatus <em>Status</em>}</li>
 *   <li>{@link rilaiot.tv#getCloud_tv <em>Cloud tv</em>}</li>
 *   <li>{@link rilaiot.tv#getAtuador_tv <em>Atuador tv</em>}</li>
 *   <li>{@link rilaiot.tv#getSensor_tv <em>Sensor tv</em>}</li>
 * </ul>
 *
 * @see rilaiot.RilaiotPackage#gettv()
 * @model
 * @generated
 */
public interface tv extends EObject {
	/**
	 * Returns the value of the '<em><b>Ip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ip</em>' attribute.
	 * @see #setIp(String)
	 * @see rilaiot.RilaiotPackage#gettv_Ip()
	 * @model required="true"
	 * @generated
	 */
	String getIp();

	/**
	 * Sets the value of the '{@link rilaiot.tv#getIp <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ip</em>' attribute.
	 * @see #getIp()
	 * @generated
	 */
	void setIp(String value);

	/**
	 * Returns the value of the '<em><b>Canal</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Canal</em>' attribute.
	 * @see #setCanal(int)
	 * @see rilaiot.RilaiotPackage#gettv_Canal()
	 * @model required="true"
	 * @generated
	 */
	int getCanal();

	/**
	 * Sets the value of the '{@link rilaiot.tv#getCanal <em>Canal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Canal</em>' attribute.
	 * @see #getCanal()
	 * @generated
	 */
	void setCanal(int value);

	/**
	 * Returns the value of the '<em><b>Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Status</em>' attribute.
	 * @see #setStatus(boolean)
	 * @see rilaiot.RilaiotPackage#gettv_Status()
	 * @model required="true"
	 * @generated
	 */
	boolean isStatus();

	/**
	 * Sets the value of the '{@link rilaiot.tv#isStatus <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Status</em>' attribute.
	 * @see #isStatus()
	 * @generated
	 */
	void setStatus(boolean value);

	/**
	 * Returns the value of the '<em><b>Cloud tv</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiot.cloud}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cloud tv</em>' containment reference list.
	 * @see rilaiot.RilaiotPackage#gettv_Cloud_tv()
	 * @model containment="true"
	 * @generated
	 */
	EList<cloud> getCloud_tv();

	/**
	 * Returns the value of the '<em><b>Atuador tv</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiot.atuador}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Atuador tv</em>' containment reference list.
	 * @see rilaiot.RilaiotPackage#gettv_Atuador_tv()
	 * @model containment="true"
	 * @generated
	 */
	EList<atuador> getAtuador_tv();

	/**
	 * Returns the value of the '<em><b>Sensor tv</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiot.sensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sensor tv</em>' containment reference list.
	 * @see rilaiot.RilaiotPackage#gettv_Sensor_tv()
	 * @model containment="true"
	 * @generated
	 */
	EList<sensor> getSensor_tv();

} // tv
