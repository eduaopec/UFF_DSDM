/**
 */
package rilaiot;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link rilaiot.sensor#getIp <em>Ip</em>}</li>
 *   <li>{@link rilaiot.sensor#getMensagem_sensor <em>Mensagem sensor</em>}</li>
 * </ul>
 *
 * @see rilaiot.RilaiotPackage#getsensor()
 * @model
 * @generated
 */
public interface sensor extends EObject {
	/**
	 * Returns the value of the '<em><b>Ip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ip</em>' attribute.
	 * @see #setIp(String)
	 * @see rilaiot.RilaiotPackage#getsensor_Ip()
	 * @model required="true"
	 * @generated
	 */
	String getIp();

	/**
	 * Sets the value of the '{@link rilaiot.sensor#getIp <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ip</em>' attribute.
	 * @see #getIp()
	 * @generated
	 */
	void setIp(String value);

	/**
	 * Returns the value of the '<em><b>Mensagem sensor</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiot.mensagem}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mensagem sensor</em>' containment reference list.
	 * @see rilaiot.RilaiotPackage#getsensor_Mensagem_sensor()
	 * @model containment="true"
	 * @generated
	 */
	EList<mensagem> getMensagem_sensor();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void informa_Status(String ip, boolean status);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void informa_Canal(String ip, int canal);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void informa_temperatura(String ip, float temperatura);

} // sensor
