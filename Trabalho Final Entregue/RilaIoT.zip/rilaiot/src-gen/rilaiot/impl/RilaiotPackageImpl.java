/**
 */
package rilaiot.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import rilaiot.RilaiotFactory;
import rilaiot.RilaiotPackage;
import rilaiot.aplicacao;
import rilaiot.atuador;
import rilaiot.cloud;
import rilaiot.geladeira;
import rilaiot.mensagem;
import rilaiot.mensageria;
import rilaiot.sensor;
import rilaiot.tv;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class RilaiotPackageImpl extends EPackageImpl implements RilaiotPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass aplicacaoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass geladeiraEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tvEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mensageriaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cloudEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass atuadorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mensagemEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see rilaiot.RilaiotPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private RilaiotPackageImpl() {
		super(eNS_URI, RilaiotFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link RilaiotPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static RilaiotPackage init() {
		if (isInited)
			return (RilaiotPackage) EPackage.Registry.INSTANCE.getEPackage(RilaiotPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredRilaiotPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		RilaiotPackageImpl theRilaiotPackage = registeredRilaiotPackage instanceof RilaiotPackageImpl
				? (RilaiotPackageImpl) registeredRilaiotPackage
				: new RilaiotPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theRilaiotPackage.createPackageContents();

		// Initialize created meta-data
		theRilaiotPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theRilaiotPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(RilaiotPackage.eNS_URI, theRilaiotPackage);
		return theRilaiotPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getaplicacao() {
		return aplicacaoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getaplicacao_Nome() {
		return (EAttribute) aplicacaoEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getaplicacao_Geladeira() {
		return (EReference) aplicacaoEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getaplicacao_Tv() {
		return (EReference) aplicacaoEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getaplicacao_Mensageria() {
		return (EReference) aplicacaoEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getgeladeira() {
		return geladeiraEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getgeladeira_Ip() {
		return (EAttribute) geladeiraEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getgeladeira_Temperatura() {
		return (EAttribute) geladeiraEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getgeladeira_Status() {
		return (EAttribute) geladeiraEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getgeladeira_Cloud_geladeira() {
		return (EReference) geladeiraEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getgeladeira_Atuador_geladeira() {
		return (EReference) geladeiraEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getgeladeira_Sensor_geladeira() {
		return (EReference) geladeiraEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass gettv() {
		return tvEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute gettv_Ip() {
		return (EAttribute) tvEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute gettv_Canal() {
		return (EAttribute) tvEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute gettv_Status() {
		return (EAttribute) tvEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference gettv_Cloud_tv() {
		return (EReference) tvEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference gettv_Atuador_tv() {
		return (EReference) tvEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference gettv_Sensor_tv() {
		return (EReference) tvEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getmensageria() {
		return mensageriaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getmensageria_Ip() {
		return (EAttribute) mensageriaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getmensageria__Publish__String_String() {
		return mensageriaEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getmensageria__Armazena_Mensagem__String_String() {
		return mensageriaEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getmensageria__Recupera_Mensagem__String_String() {
		return mensageriaEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getmensageria__Subscribe__String_String() {
		return mensageriaEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getmensageria__Unsubscribe__String_String() {
		return mensageriaEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getcloud() {
		return cloudEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getcloud_Ip() {
		return (EAttribute) cloudEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getcloud_Canal() {
		return (EAttribute) cloudEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getcloud_Status() {
		return (EAttribute) cloudEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getcloud_Temperatura() {
		return (EAttribute) cloudEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getcloud__Armazena_Canal__String_int() {
		return cloudEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getcloud__Armazena_Temperatura__String_int() {
		return cloudEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getcloud__Armazena_Status__String_boolean() {
		return cloudEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getcloud__Recupera_Canal__String_int() {
		return cloudEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getcloud__Recupera_Temperatura__String_float() {
		return cloudEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getcloud__Recupera_Status__String_boolean() {
		return cloudEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getsensor() {
		return sensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getsensor_Ip() {
		return (EAttribute) sensorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getsensor_Mensagem_sensor() {
		return (EReference) sensorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getsensor__Informa_Status__String_boolean() {
		return sensorEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getsensor__Informa_Canal__String_int() {
		return sensorEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getsensor__Informa_temperatura__String_float() {
		return sensorEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getatuador() {
		return atuadorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getatuador_Ip() {
		return (EAttribute) atuadorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getatuador_Mensagem_atuador() {
		return (EReference) atuadorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getatuador__Muda_Status__String_boolean() {
		return atuadorEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getatuador__Muda_Canal__String_int() {
		return atuadorEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getatuador__Muda_Temperatura__String_float() {
		return atuadorEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getmensagem() {
		return mensagemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getmensagem_Ip_origem() {
		return (EAttribute) mensagemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getmensagem_Topico() {
		return (EAttribute) mensagemEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getmensagem_Mensagem() {
		return (EAttribute) mensagemEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getmensagem_Status() {
		return (EAttribute) mensagemEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RilaiotFactory getRilaiotFactory() {
		return (RilaiotFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		aplicacaoEClass = createEClass(APLICACAO);
		createEAttribute(aplicacaoEClass, APLICACAO__NOME);
		createEReference(aplicacaoEClass, APLICACAO__GELADEIRA);
		createEReference(aplicacaoEClass, APLICACAO__TV);
		createEReference(aplicacaoEClass, APLICACAO__MENSAGERIA);

		geladeiraEClass = createEClass(GELADEIRA);
		createEAttribute(geladeiraEClass, GELADEIRA__IP);
		createEAttribute(geladeiraEClass, GELADEIRA__TEMPERATURA);
		createEAttribute(geladeiraEClass, GELADEIRA__STATUS);
		createEReference(geladeiraEClass, GELADEIRA__CLOUD_GELADEIRA);
		createEReference(geladeiraEClass, GELADEIRA__ATUADOR_GELADEIRA);
		createEReference(geladeiraEClass, GELADEIRA__SENSOR_GELADEIRA);

		tvEClass = createEClass(TV);
		createEAttribute(tvEClass, TV__IP);
		createEAttribute(tvEClass, TV__CANAL);
		createEAttribute(tvEClass, TV__STATUS);
		createEReference(tvEClass, TV__CLOUD_TV);
		createEReference(tvEClass, TV__ATUADOR_TV);
		createEReference(tvEClass, TV__SENSOR_TV);

		mensageriaEClass = createEClass(MENSAGERIA);
		createEAttribute(mensageriaEClass, MENSAGERIA__IP);
		createEOperation(mensageriaEClass, MENSAGERIA___PUBLISH__STRING_STRING);
		createEOperation(mensageriaEClass, MENSAGERIA___ARMAZENA_MENSAGEM__STRING_STRING);
		createEOperation(mensageriaEClass, MENSAGERIA___RECUPERA_MENSAGEM__STRING_STRING);
		createEOperation(mensageriaEClass, MENSAGERIA___SUBSCRIBE__STRING_STRING);
		createEOperation(mensageriaEClass, MENSAGERIA___UNSUBSCRIBE__STRING_STRING);

		cloudEClass = createEClass(CLOUD);
		createEAttribute(cloudEClass, CLOUD__IP);
		createEAttribute(cloudEClass, CLOUD__CANAL);
		createEAttribute(cloudEClass, CLOUD__STATUS);
		createEAttribute(cloudEClass, CLOUD__TEMPERATURA);
		createEOperation(cloudEClass, CLOUD___ARMAZENA_CANAL__STRING_INT);
		createEOperation(cloudEClass, CLOUD___ARMAZENA_TEMPERATURA__STRING_INT);
		createEOperation(cloudEClass, CLOUD___ARMAZENA_STATUS__STRING_BOOLEAN);
		createEOperation(cloudEClass, CLOUD___RECUPERA_CANAL__STRING_INT);
		createEOperation(cloudEClass, CLOUD___RECUPERA_TEMPERATURA__STRING_FLOAT);
		createEOperation(cloudEClass, CLOUD___RECUPERA_STATUS__STRING_BOOLEAN);

		sensorEClass = createEClass(SENSOR);
		createEAttribute(sensorEClass, SENSOR__IP);
		createEReference(sensorEClass, SENSOR__MENSAGEM_SENSOR);
		createEOperation(sensorEClass, SENSOR___INFORMA_STATUS__STRING_BOOLEAN);
		createEOperation(sensorEClass, SENSOR___INFORMA_CANAL__STRING_INT);
		createEOperation(sensorEClass, SENSOR___INFORMA_TEMPERATURA__STRING_FLOAT);

		atuadorEClass = createEClass(ATUADOR);
		createEAttribute(atuadorEClass, ATUADOR__IP);
		createEReference(atuadorEClass, ATUADOR__MENSAGEM_ATUADOR);
		createEOperation(atuadorEClass, ATUADOR___MUDA_STATUS__STRING_BOOLEAN);
		createEOperation(atuadorEClass, ATUADOR___MUDA_CANAL__STRING_INT);
		createEOperation(atuadorEClass, ATUADOR___MUDA_TEMPERATURA__STRING_FLOAT);

		mensagemEClass = createEClass(MENSAGEM);
		createEAttribute(mensagemEClass, MENSAGEM__IP_ORIGEM);
		createEAttribute(mensagemEClass, MENSAGEM__TOPICO);
		createEAttribute(mensagemEClass, MENSAGEM__MENSAGEM);
		createEAttribute(mensagemEClass, MENSAGEM__STATUS);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes, features, and operations; add parameters
		initEClass(aplicacaoEClass, aplicacao.class, "aplicacao", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getaplicacao_Nome(), ecorePackage.getEString(), "nome", null, 1, 1, aplicacao.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getaplicacao_Geladeira(), this.getgeladeira(), null, "geladeira", null, 0, -1, aplicacao.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getaplicacao_Tv(), this.gettv(), null, "tv", null, 0, -1, aplicacao.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getaplicacao_Mensageria(), this.getmensageria(), null, "mensageria", null, 1, 1, aplicacao.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(geladeiraEClass, geladeira.class, "geladeira", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getgeladeira_Ip(), ecorePackage.getEString(), "ip", null, 1, 1, geladeira.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getgeladeira_Temperatura(), ecorePackage.getEFloat(), "temperatura", null, 1, 1, geladeira.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getgeladeira_Status(), ecorePackage.getEBoolean(), "status", null, 1, 1, geladeira.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getgeladeira_Cloud_geladeira(), this.getcloud(), null, "cloud_geladeira", null, 0, -1,
				geladeira.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getgeladeira_Atuador_geladeira(), this.getatuador(), null, "atuador_geladeira", null, 0, -1,
				geladeira.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getgeladeira_Sensor_geladeira(), this.getsensor(), null, "sensor_geladeira", null, 0, -1,
				geladeira.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tvEClass, tv.class, "tv", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(gettv_Ip(), ecorePackage.getEString(), "ip", null, 1, 1, tv.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(gettv_Canal(), ecorePackage.getEInt(), "canal", null, 1, 1, tv.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(gettv_Status(), ecorePackage.getEBoolean(), "status", null, 1, 1, tv.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(gettv_Cloud_tv(), this.getcloud(), null, "cloud_tv", null, 0, -1, tv.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(gettv_Atuador_tv(), this.getatuador(), null, "atuador_tv", null, 0, -1, tv.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(gettv_Sensor_tv(), this.getsensor(), null, "sensor_tv", null, 0, -1, tv.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(mensageriaEClass, mensageria.class, "mensageria", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getmensageria_Ip(), ecorePackage.getEString(), "ip", null, 1, 1, mensageria.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		EOperation op = initEOperation(getmensageria__Publish__String_String(), null, "publish", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ipSubscribe", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "mensagem", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getmensageria__Armazena_Mensagem__String_String(), null, "armazena_Mensagem", 0, 1,
				IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "mensagem", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getmensageria__Recupera_Mensagem__String_String(), null, "recupera_Mensagem", 0, 1,
				IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "mensagem", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getmensageria__Subscribe__String_String(), null, "subscribe", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip_cliente", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "topico", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getmensageria__Unsubscribe__String_String(), null, "unsubscribe", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip_cliente", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "topico", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(cloudEClass, cloud.class, "cloud", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getcloud_Ip(), ecorePackage.getEString(), "ip", null, 1, 1, cloud.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getcloud_Canal(), ecorePackage.getEInt(), "canal", null, 1, 1, cloud.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getcloud_Status(), ecorePackage.getEBoolean(), "status", null, 1, 1, cloud.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getcloud_Temperatura(), ecorePackage.getEFloat(), "temperatura", null, 1, 1, cloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		op = initEOperation(getcloud__Armazena_Canal__String_int(), null, "armazena_Canal", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEInt(), "canal", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getcloud__Armazena_Temperatura__String_int(), null, "armazena_Temperatura", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEInt(), "temperatura", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getcloud__Armazena_Status__String_boolean(), null, "armazena_Status", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEBoolean(), "status", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getcloud__Recupera_Canal__String_int(), null, "recupera_Canal", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEInt(), "canal", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getcloud__Recupera_Temperatura__String_float(), null, "recupera_Temperatura", 0, 1,
				IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEFloat(), "temperatura", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getcloud__Recupera_Status__String_boolean(), null, "recupera_Status", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEBoolean(), "status", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(sensorEClass, sensor.class, "sensor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getsensor_Ip(), ecorePackage.getEString(), "ip", null, 1, 1, sensor.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getsensor_Mensagem_sensor(), this.getmensagem(), null, "mensagem_sensor", null, 0, -1,
				sensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		op = initEOperation(getsensor__Informa_Status__String_boolean(), null, "informa_Status", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEBoolean(), "status", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getsensor__Informa_Canal__String_int(), null, "informa_Canal", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEInt(), "canal", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getsensor__Informa_temperatura__String_float(), null, "informa_temperatura", 0, 1,
				IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEFloat(), "temperatura", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(atuadorEClass, atuador.class, "atuador", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getatuador_Ip(), ecorePackage.getEString(), "ip", null, 1, 1, atuador.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getatuador_Mensagem_atuador(), this.getmensagem(), null, "mensagem_atuador", null, 0, -1,
				atuador.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		op = initEOperation(getatuador__Muda_Status__String_boolean(), null, "muda_Status", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEBoolean(), "status", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getatuador__Muda_Canal__String_int(), null, "muda_Canal", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEInt(), "canal", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getatuador__Muda_Temperatura__String_float(), null, "muda_Temperatura", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, ecorePackage.getEString(), "ip", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEFloat(), "temperatura", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(mensagemEClass, mensagem.class, "mensagem", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getmensagem_Ip_origem(), ecorePackage.getEString(), "ip_origem", null, 1, 1, mensagem.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getmensagem_Topico(), ecorePackage.getEString(), "topico", null, 1, 1, mensagem.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getmensagem_Mensagem(), ecorePackage.getEString(), "mensagem", null, 1, 1, mensagem.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getmensagem_Status(), ecorePackage.getEBoolean(), "status", null, 1, 1, mensagem.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //RilaiotPackageImpl
