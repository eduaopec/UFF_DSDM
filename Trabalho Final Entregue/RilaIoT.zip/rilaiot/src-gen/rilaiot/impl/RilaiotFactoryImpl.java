/**
 */
package rilaiot.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import rilaiot.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class RilaiotFactoryImpl extends EFactoryImpl implements RilaiotFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static RilaiotFactory init() {
		try {
			RilaiotFactory theRilaiotFactory = (RilaiotFactory) EPackage.Registry.INSTANCE
					.getEFactory(RilaiotPackage.eNS_URI);
			if (theRilaiotFactory != null) {
				return theRilaiotFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new RilaiotFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RilaiotFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case RilaiotPackage.APLICACAO:
			return createaplicacao();
		case RilaiotPackage.GELADEIRA:
			return creategeladeira();
		case RilaiotPackage.TV:
			return createtv();
		case RilaiotPackage.MENSAGERIA:
			return createmensageria();
		case RilaiotPackage.CLOUD:
			return createcloud();
		case RilaiotPackage.SENSOR:
			return createsensor();
		case RilaiotPackage.ATUADOR:
			return createatuador();
		case RilaiotPackage.MENSAGEM:
			return createmensagem();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public aplicacao createaplicacao() {
		aplicacaoImpl aplicacao = new aplicacaoImpl();
		return aplicacao;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public geladeira creategeladeira() {
		geladeiraImpl geladeira = new geladeiraImpl();
		return geladeira;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public tv createtv() {
		tvImpl tv = new tvImpl();
		return tv;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public mensageria createmensageria() {
		mensageriaImpl mensageria = new mensageriaImpl();
		return mensageria;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public cloud createcloud() {
		cloudImpl cloud = new cloudImpl();
		return cloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public sensor createsensor() {
		sensorImpl sensor = new sensorImpl();
		return sensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public atuador createatuador() {
		atuadorImpl atuador = new atuadorImpl();
		return atuador;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public mensagem createmensagem() {
		mensagemImpl mensagem = new mensagemImpl();
		return mensagem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RilaiotPackage getRilaiotPackage() {
		return (RilaiotPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static RilaiotPackage getPackage() {
		return RilaiotPackage.eINSTANCE;
	}

} //RilaiotFactoryImpl
