/**
 */
package rilaiot.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import rilaiot.RilaiotPackage;
import rilaiot.mensagem;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>mensagem</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link rilaiot.impl.mensagemImpl#getIp_origem <em>Ip origem</em>}</li>
 *   <li>{@link rilaiot.impl.mensagemImpl#getTopico <em>Topico</em>}</li>
 *   <li>{@link rilaiot.impl.mensagemImpl#getMensagem <em>Mensagem</em>}</li>
 *   <li>{@link rilaiot.impl.mensagemImpl#isStatus <em>Status</em>}</li>
 * </ul>
 *
 * @generated
 */
public class mensagemImpl extends MinimalEObjectImpl.Container implements mensagem {
	/**
	 * The default value of the '{@link #getIp_origem() <em>Ip origem</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIp_origem()
	 * @generated
	 * @ordered
	 */
	protected static final String IP_ORIGEM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIp_origem() <em>Ip origem</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIp_origem()
	 * @generated
	 * @ordered
	 */
	protected String ip_origem = IP_ORIGEM_EDEFAULT;

	/**
	 * The default value of the '{@link #getTopico() <em>Topico</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTopico()
	 * @generated
	 * @ordered
	 */
	protected static final String TOPICO_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTopico() <em>Topico</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTopico()
	 * @generated
	 * @ordered
	 */
	protected String topico = TOPICO_EDEFAULT;

	/**
	 * The default value of the '{@link #getMensagem() <em>Mensagem</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMensagem()
	 * @generated
	 * @ordered
	 */
	protected static final String MENSAGEM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getMensagem() <em>Mensagem</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMensagem()
	 * @generated
	 * @ordered
	 */
	protected String mensagem = MENSAGEM_EDEFAULT;

	/**
	 * The default value of the '{@link #isStatus() <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isStatus()
	 * @generated
	 * @ordered
	 */
	protected static final boolean STATUS_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isStatus() <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isStatus()
	 * @generated
	 * @ordered
	 */
	protected boolean status = STATUS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected mensagemImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RilaiotPackage.Literals.MENSAGEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIp_origem() {
		return ip_origem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIp_origem(String newIp_origem) {
		String oldIp_origem = ip_origem;
		ip_origem = newIp_origem;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotPackage.MENSAGEM__IP_ORIGEM, oldIp_origem,
					ip_origem));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getTopico() {
		return topico;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTopico(String newTopico) {
		String oldTopico = topico;
		topico = newTopico;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotPackage.MENSAGEM__TOPICO, oldTopico, topico));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getMensagem() {
		return mensagem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setMensagem(String newMensagem) {
		String oldMensagem = mensagem;
		mensagem = newMensagem;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotPackage.MENSAGEM__MENSAGEM, oldMensagem,
					mensagem));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isStatus() {
		return status;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStatus(boolean newStatus) {
		boolean oldStatus = status;
		status = newStatus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotPackage.MENSAGEM__STATUS, oldStatus, status));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case RilaiotPackage.MENSAGEM__IP_ORIGEM:
			return getIp_origem();
		case RilaiotPackage.MENSAGEM__TOPICO:
			return getTopico();
		case RilaiotPackage.MENSAGEM__MENSAGEM:
			return getMensagem();
		case RilaiotPackage.MENSAGEM__STATUS:
			return isStatus();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case RilaiotPackage.MENSAGEM__IP_ORIGEM:
			setIp_origem((String) newValue);
			return;
		case RilaiotPackage.MENSAGEM__TOPICO:
			setTopico((String) newValue);
			return;
		case RilaiotPackage.MENSAGEM__MENSAGEM:
			setMensagem((String) newValue);
			return;
		case RilaiotPackage.MENSAGEM__STATUS:
			setStatus((Boolean) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case RilaiotPackage.MENSAGEM__IP_ORIGEM:
			setIp_origem(IP_ORIGEM_EDEFAULT);
			return;
		case RilaiotPackage.MENSAGEM__TOPICO:
			setTopico(TOPICO_EDEFAULT);
			return;
		case RilaiotPackage.MENSAGEM__MENSAGEM:
			setMensagem(MENSAGEM_EDEFAULT);
			return;
		case RilaiotPackage.MENSAGEM__STATUS:
			setStatus(STATUS_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case RilaiotPackage.MENSAGEM__IP_ORIGEM:
			return IP_ORIGEM_EDEFAULT == null ? ip_origem != null : !IP_ORIGEM_EDEFAULT.equals(ip_origem);
		case RilaiotPackage.MENSAGEM__TOPICO:
			return TOPICO_EDEFAULT == null ? topico != null : !TOPICO_EDEFAULT.equals(topico);
		case RilaiotPackage.MENSAGEM__MENSAGEM:
			return MENSAGEM_EDEFAULT == null ? mensagem != null : !MENSAGEM_EDEFAULT.equals(mensagem);
		case RilaiotPackage.MENSAGEM__STATUS:
			return status != STATUS_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (ip_origem: ");
		result.append(ip_origem);
		result.append(", topico: ");
		result.append(topico);
		result.append(", mensagem: ");
		result.append(mensagem);
		result.append(", status: ");
		result.append(status);
		result.append(')');
		return result.toString();
	}

} //mensagemImpl
