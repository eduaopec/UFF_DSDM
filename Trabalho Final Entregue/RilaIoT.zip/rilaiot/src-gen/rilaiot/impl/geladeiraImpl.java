/**
 */
package rilaiot.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import rilaiot.RilaiotPackage;
import rilaiot.atuador;
import rilaiot.cloud;
import rilaiot.geladeira;
import rilaiot.sensor;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>geladeira</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link rilaiot.impl.geladeiraImpl#getIp <em>Ip</em>}</li>
 *   <li>{@link rilaiot.impl.geladeiraImpl#getTemperatura <em>Temperatura</em>}</li>
 *   <li>{@link rilaiot.impl.geladeiraImpl#isStatus <em>Status</em>}</li>
 *   <li>{@link rilaiot.impl.geladeiraImpl#getCloud_geladeira <em>Cloud geladeira</em>}</li>
 *   <li>{@link rilaiot.impl.geladeiraImpl#getAtuador_geladeira <em>Atuador geladeira</em>}</li>
 *   <li>{@link rilaiot.impl.geladeiraImpl#getSensor_geladeira <em>Sensor geladeira</em>}</li>
 * </ul>
 *
 * @generated
 */
public class geladeiraImpl extends MinimalEObjectImpl.Container implements geladeira {
	/**
	 * The default value of the '{@link #getIp() <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIp()
	 * @generated
	 * @ordered
	 */
	protected static final String IP_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIp() <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIp()
	 * @generated
	 * @ordered
	 */
	protected String ip = IP_EDEFAULT;

	/**
	 * The default value of the '{@link #getTemperatura() <em>Temperatura</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTemperatura()
	 * @generated
	 * @ordered
	 */
	protected static final float TEMPERATURA_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getTemperatura() <em>Temperatura</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTemperatura()
	 * @generated
	 * @ordered
	 */
	protected float temperatura = TEMPERATURA_EDEFAULT;

	/**
	 * The default value of the '{@link #isStatus() <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isStatus()
	 * @generated
	 * @ordered
	 */
	protected static final boolean STATUS_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isStatus() <em>Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isStatus()
	 * @generated
	 * @ordered
	 */
	protected boolean status = STATUS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCloud_geladeira() <em>Cloud geladeira</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCloud_geladeira()
	 * @generated
	 * @ordered
	 */
	protected EList<cloud> cloud_geladeira;

	/**
	 * The cached value of the '{@link #getAtuador_geladeira() <em>Atuador geladeira</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAtuador_geladeira()
	 * @generated
	 * @ordered
	 */
	protected EList<atuador> atuador_geladeira;

	/**
	 * The cached value of the '{@link #getSensor_geladeira() <em>Sensor geladeira</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSensor_geladeira()
	 * @generated
	 * @ordered
	 */
	protected EList<sensor> sensor_geladeira;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected geladeiraImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RilaiotPackage.Literals.GELADEIRA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIp() {
		return ip;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIp(String newIp) {
		String oldIp = ip;
		ip = newIp;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotPackage.GELADEIRA__IP, oldIp, ip));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getTemperatura() {
		return temperatura;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTemperatura(float newTemperatura) {
		float oldTemperatura = temperatura;
		temperatura = newTemperatura;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotPackage.GELADEIRA__TEMPERATURA, oldTemperatura,
					temperatura));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isStatus() {
		return status;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStatus(boolean newStatus) {
		boolean oldStatus = status;
		status = newStatus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotPackage.GELADEIRA__STATUS, oldStatus, status));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<cloud> getCloud_geladeira() {
		if (cloud_geladeira == null) {
			cloud_geladeira = new EObjectContainmentEList<cloud>(cloud.class, this,
					RilaiotPackage.GELADEIRA__CLOUD_GELADEIRA);
		}
		return cloud_geladeira;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<atuador> getAtuador_geladeira() {
		if (atuador_geladeira == null) {
			atuador_geladeira = new EObjectContainmentEList<atuador>(atuador.class, this,
					RilaiotPackage.GELADEIRA__ATUADOR_GELADEIRA);
		}
		return atuador_geladeira;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<sensor> getSensor_geladeira() {
		if (sensor_geladeira == null) {
			sensor_geladeira = new EObjectContainmentEList<sensor>(sensor.class, this,
					RilaiotPackage.GELADEIRA__SENSOR_GELADEIRA);
		}
		return sensor_geladeira;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case RilaiotPackage.GELADEIRA__CLOUD_GELADEIRA:
			return ((InternalEList<?>) getCloud_geladeira()).basicRemove(otherEnd, msgs);
		case RilaiotPackage.GELADEIRA__ATUADOR_GELADEIRA:
			return ((InternalEList<?>) getAtuador_geladeira()).basicRemove(otherEnd, msgs);
		case RilaiotPackage.GELADEIRA__SENSOR_GELADEIRA:
			return ((InternalEList<?>) getSensor_geladeira()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case RilaiotPackage.GELADEIRA__IP:
			return getIp();
		case RilaiotPackage.GELADEIRA__TEMPERATURA:
			return getTemperatura();
		case RilaiotPackage.GELADEIRA__STATUS:
			return isStatus();
		case RilaiotPackage.GELADEIRA__CLOUD_GELADEIRA:
			return getCloud_geladeira();
		case RilaiotPackage.GELADEIRA__ATUADOR_GELADEIRA:
			return getAtuador_geladeira();
		case RilaiotPackage.GELADEIRA__SENSOR_GELADEIRA:
			return getSensor_geladeira();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case RilaiotPackage.GELADEIRA__IP:
			setIp((String) newValue);
			return;
		case RilaiotPackage.GELADEIRA__TEMPERATURA:
			setTemperatura((Float) newValue);
			return;
		case RilaiotPackage.GELADEIRA__STATUS:
			setStatus((Boolean) newValue);
			return;
		case RilaiotPackage.GELADEIRA__CLOUD_GELADEIRA:
			getCloud_geladeira().clear();
			getCloud_geladeira().addAll((Collection<? extends cloud>) newValue);
			return;
		case RilaiotPackage.GELADEIRA__ATUADOR_GELADEIRA:
			getAtuador_geladeira().clear();
			getAtuador_geladeira().addAll((Collection<? extends atuador>) newValue);
			return;
		case RilaiotPackage.GELADEIRA__SENSOR_GELADEIRA:
			getSensor_geladeira().clear();
			getSensor_geladeira().addAll((Collection<? extends sensor>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case RilaiotPackage.GELADEIRA__IP:
			setIp(IP_EDEFAULT);
			return;
		case RilaiotPackage.GELADEIRA__TEMPERATURA:
			setTemperatura(TEMPERATURA_EDEFAULT);
			return;
		case RilaiotPackage.GELADEIRA__STATUS:
			setStatus(STATUS_EDEFAULT);
			return;
		case RilaiotPackage.GELADEIRA__CLOUD_GELADEIRA:
			getCloud_geladeira().clear();
			return;
		case RilaiotPackage.GELADEIRA__ATUADOR_GELADEIRA:
			getAtuador_geladeira().clear();
			return;
		case RilaiotPackage.GELADEIRA__SENSOR_GELADEIRA:
			getSensor_geladeira().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case RilaiotPackage.GELADEIRA__IP:
			return IP_EDEFAULT == null ? ip != null : !IP_EDEFAULT.equals(ip);
		case RilaiotPackage.GELADEIRA__TEMPERATURA:
			return temperatura != TEMPERATURA_EDEFAULT;
		case RilaiotPackage.GELADEIRA__STATUS:
			return status != STATUS_EDEFAULT;
		case RilaiotPackage.GELADEIRA__CLOUD_GELADEIRA:
			return cloud_geladeira != null && !cloud_geladeira.isEmpty();
		case RilaiotPackage.GELADEIRA__ATUADOR_GELADEIRA:
			return atuador_geladeira != null && !atuador_geladeira.isEmpty();
		case RilaiotPackage.GELADEIRA__SENSOR_GELADEIRA:
			return sensor_geladeira != null && !sensor_geladeira.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (ip: ");
		result.append(ip);
		result.append(", temperatura: ");
		result.append(temperatura);
		result.append(", status: ");
		result.append(status);
		result.append(')');
		return result.toString();
	}

} //geladeiraImpl
