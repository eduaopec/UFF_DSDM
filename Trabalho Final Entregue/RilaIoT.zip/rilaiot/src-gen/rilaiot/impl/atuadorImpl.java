/**
 */
package rilaiot.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import rilaiot.RilaiotPackage;
import rilaiot.atuador;
import rilaiot.mensagem;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>atuador</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link rilaiot.impl.atuadorImpl#getIp <em>Ip</em>}</li>
 *   <li>{@link rilaiot.impl.atuadorImpl#getMensagem_atuador <em>Mensagem atuador</em>}</li>
 * </ul>
 *
 * @generated
 */
public class atuadorImpl extends MinimalEObjectImpl.Container implements atuador {
	/**
	 * The default value of the '{@link #getIp() <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIp()
	 * @generated
	 * @ordered
	 */
	protected static final String IP_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIp() <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIp()
	 * @generated
	 * @ordered
	 */
	protected String ip = IP_EDEFAULT;

	/**
	 * The cached value of the '{@link #getMensagem_atuador() <em>Mensagem atuador</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMensagem_atuador()
	 * @generated
	 * @ordered
	 */
	protected EList<mensagem> mensagem_atuador;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected atuadorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RilaiotPackage.Literals.ATUADOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIp() {
		return ip;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIp(String newIp) {
		String oldIp = ip;
		ip = newIp;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RilaiotPackage.ATUADOR__IP, oldIp, ip));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<mensagem> getMensagem_atuador() {
		if (mensagem_atuador == null) {
			mensagem_atuador = new EObjectContainmentEList<mensagem>(mensagem.class, this,
					RilaiotPackage.ATUADOR__MENSAGEM_ATUADOR);
		}
		return mensagem_atuador;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void muda_Status(String ip, boolean status) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void muda_Canal(String ip, int canal) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void muda_Temperatura(String ip, float temperatura) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case RilaiotPackage.ATUADOR__MENSAGEM_ATUADOR:
			return ((InternalEList<?>) getMensagem_atuador()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case RilaiotPackage.ATUADOR__IP:
			return getIp();
		case RilaiotPackage.ATUADOR__MENSAGEM_ATUADOR:
			return getMensagem_atuador();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case RilaiotPackage.ATUADOR__IP:
			setIp((String) newValue);
			return;
		case RilaiotPackage.ATUADOR__MENSAGEM_ATUADOR:
			getMensagem_atuador().clear();
			getMensagem_atuador().addAll((Collection<? extends mensagem>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case RilaiotPackage.ATUADOR__IP:
			setIp(IP_EDEFAULT);
			return;
		case RilaiotPackage.ATUADOR__MENSAGEM_ATUADOR:
			getMensagem_atuador().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case RilaiotPackage.ATUADOR__IP:
			return IP_EDEFAULT == null ? ip != null : !IP_EDEFAULT.equals(ip);
		case RilaiotPackage.ATUADOR__MENSAGEM_ATUADOR:
			return mensagem_atuador != null && !mensagem_atuador.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RilaiotPackage.ATUADOR___MUDA_STATUS__STRING_BOOLEAN:
			muda_Status((String) arguments.get(0), (Boolean) arguments.get(1));
			return null;
		case RilaiotPackage.ATUADOR___MUDA_CANAL__STRING_INT:
			muda_Canal((String) arguments.get(0), (Integer) arguments.get(1));
			return null;
		case RilaiotPackage.ATUADOR___MUDA_TEMPERATURA__STRING_FLOAT:
			muda_Temperatura((String) arguments.get(0), (Float) arguments.get(1));
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (ip: ");
		result.append(ip);
		result.append(')');
		return result.toString();
	}

} //atuadorImpl
