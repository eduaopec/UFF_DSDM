/**
 */
package rilaiot;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>aplicacao</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link rilaiot.aplicacao#getNome <em>Nome</em>}</li>
 *   <li>{@link rilaiot.aplicacao#getGeladeira <em>Geladeira</em>}</li>
 *   <li>{@link rilaiot.aplicacao#getTv <em>Tv</em>}</li>
 *   <li>{@link rilaiot.aplicacao#getMensageria <em>Mensageria</em>}</li>
 * </ul>
 *
 * @see rilaiot.RilaiotPackage#getaplicacao()
 * @model
 * @generated
 */
public interface aplicacao extends EObject {
	/**
	 * Returns the value of the '<em><b>Nome</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nome</em>' attribute.
	 * @see #setNome(String)
	 * @see rilaiot.RilaiotPackage#getaplicacao_Nome()
	 * @model required="true"
	 * @generated
	 */
	String getNome();

	/**
	 * Sets the value of the '{@link rilaiot.aplicacao#getNome <em>Nome</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nome</em>' attribute.
	 * @see #getNome()
	 * @generated
	 */
	void setNome(String value);

	/**
	 * Returns the value of the '<em><b>Geladeira</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiot.geladeira}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Geladeira</em>' containment reference list.
	 * @see rilaiot.RilaiotPackage#getaplicacao_Geladeira()
	 * @model containment="true"
	 * @generated
	 */
	EList<geladeira> getGeladeira();

	/**
	 * Returns the value of the '<em><b>Tv</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiot.tv}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tv</em>' containment reference list.
	 * @see rilaiot.RilaiotPackage#getaplicacao_Tv()
	 * @model containment="true"
	 * @generated
	 */
	EList<tv> getTv();

	/**
	 * Returns the value of the '<em><b>Mensageria</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mensageria</em>' containment reference.
	 * @see #setMensageria(mensageria)
	 * @see rilaiot.RilaiotPackage#getaplicacao_Mensageria()
	 * @model containment="true" required="true"
	 * @generated
	 */
	mensageria getMensageria();

	/**
	 * Sets the value of the '{@link rilaiot.aplicacao#getMensageria <em>Mensageria</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Mensageria</em>' containment reference.
	 * @see #getMensageria()
	 * @generated
	 */
	void setMensageria(mensageria value);

} // aplicacao
