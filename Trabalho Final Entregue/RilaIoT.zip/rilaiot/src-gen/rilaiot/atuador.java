/**
 */
package rilaiot;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>atuador</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link rilaiot.atuador#getIp <em>Ip</em>}</li>
 *   <li>{@link rilaiot.atuador#getMensagem_atuador <em>Mensagem atuador</em>}</li>
 * </ul>
 *
 * @see rilaiot.RilaiotPackage#getatuador()
 * @model
 * @generated
 */
public interface atuador extends EObject {
	/**
	 * Returns the value of the '<em><b>Ip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ip</em>' attribute.
	 * @see #setIp(String)
	 * @see rilaiot.RilaiotPackage#getatuador_Ip()
	 * @model required="true"
	 * @generated
	 */
	String getIp();

	/**
	 * Sets the value of the '{@link rilaiot.atuador#getIp <em>Ip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ip</em>' attribute.
	 * @see #getIp()
	 * @generated
	 */
	void setIp(String value);

	/**
	 * Returns the value of the '<em><b>Mensagem atuador</b></em>' containment reference list.
	 * The list contents are of type {@link rilaiot.mensagem}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mensagem atuador</em>' containment reference list.
	 * @see rilaiot.RilaiotPackage#getatuador_Mensagem_atuador()
	 * @model containment="true"
	 * @generated
	 */
	EList<mensagem> getMensagem_atuador();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void muda_Status(String ip, boolean status);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void muda_Canal(String ip, int canal);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void muda_Temperatura(String ip, float temperatura);

} // atuador
